import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import fs from "fs";

interface Category {
  id: string;
  name: string;
  slug: string;
}

interface Author {
  id: string;
  name: string;
  bio: string;
}

interface Book {
  id: string;
  title: string;
  authorId: string;
  categoryId: string;
  coverUrl: string;
  description: string;
  stock: number;
  rentalPrice: number;
  rentalDuration: number;
}

interface Member {
  id: string;
  name: string;
  email: string;
  phone: string;
  membershipType: 'Regular' | 'Premium';
}

interface Loan {
  id: string;
  memberId: string;
  bookId: string;
  loanDate: string;
  returnDate: string | null;
  status: 'Active' | 'Returned';
  totalFee: number;
}

const DATA_FILE = path.join(process.cwd(), "data-store.json");

// Default relational database seed data
const DEFAULT_AUTHORS: Author[] = [
  { id: "auth_1", name: "Tatsuki Fujimoto", bio: "Kreator manga asal Jepang terkenal dengan karya bertema gelap dan absurd seperti Chainsaw Man." },
  { id: "auth_2", name: "R.A. Kosasih", bio: "Bapak Komik Indonesia, pionir komik wayang klasik yang melegenda." },
  { id: "auth_3", name: "Tere Liye", bio: "Penulis novel produktif Indonesia dengan puluhan karya best-seller berkelas nasional." },
  { id: "auth_4", name: "Andrea Hirata", bio: "Novelist inspiratif, penulis Laskar Pelangi yang melambungkan nama Belitung ke seluruh penjuru dunia." },
  { id: "auth_5", name: "Isman H. Suryaman", bio: "Penulis literatur pemrograman web dan sistem berbasis teknologi modern." }
];

const DEFAULT_CATEGORIES: Category[] = [
  { id: "cat_1", name: "Komik Jepang (Manga)", slug: "manga" },
  { id: "cat_2", name: "Komik Nusantara", slug: "komik-lokal" },
  { id: "cat_3", name: "Novel Sastra", slug: "novel-sastra" },
  { id: "cat_4", name: "Buku Teknologi", slug: "teknologi" },
  { id: "cat_5", name: "Pendidikan & Sains", slug: "pendidikan" }
];

const DEFAULT_BOOKS: Book[] = [
  {
    id: "book_1",
    title: "Chainsaw Man Vol. 1",
    authorId: "auth_1",
    categoryId: "cat_1",
    coverUrl: "https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?w=600&auto=format&fit=crop&q=60",
    description: "Denji adalah pemburu iblis miskin yang melakukan kontrak mistis dengan anjing iblis gergaji bernama Pochita.",
    stock: 7,
    rentalPrice: 5000,
    rentalDuration: 3
  },
  {
    id: "book_2",
    title: "Mahabharata: Compilation Edition",
    authorId: "auth_2",
    categoryId: "cat_2",
    coverUrl: "https://images.unsplash.com/photo-1614850523459-c2f4c699c52e?w=600&auto=format&fit=crop&q=60",
    description: "Karya agung legendaris R.A Kosasih menceritakan kisah epik kesatria Pandawa dan Kurawa di padang Kurukshetra.",
    stock: 3,
    rentalPrice: 8000,
    rentalDuration: 5
  },
  {
    id: "book_3",
    title: "Bumi (Saga Dunia Paralel)",
    authorId: "auth_3",
    categoryId: "cat_3",
    coverUrl: "https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=600&auto=format&fit=crop&q=60",
    description: "Pertualangan seru Raib, Seli, dan Ali melintasi portal ke dimensi Klan Bulan yang penuh sihir dan teknologi tinggi.",
    stock: 5,
    rentalPrice: 6000,
    rentalDuration: 7
  },
  {
    id: "book_4",
    title: "Laskar Pelangi",
    authorId: "auth_4",
    categoryId: "cat_3",
    coverUrl: "https://images.unsplash.com/photo-1512820790803-83ca734da794?w=600&auto=format&fit=crop&q=60",
    description: "Kisah mengharukan perjuangan 10 murid Laskar Pelangi bersama guru tangguh mereka di Gantong, pulau Belitung.",
    stock: 10,
    rentalPrice: 4000,
    rentalDuration: 7
  },
  {
    id: "book_5",
    title: "Seni Pemrograman React & Vue modern",
    authorId: "auth_5",
    categoryId: "cat_4",
    coverUrl: "https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=600&auto=format&fit=crop&q=60",
    description: "Panduan komprehensif menguasai pengembangan aplikasi decoupled SPA menggunakan ekosistem terbaru Javascript.",
    stock: 4,
    rentalPrice: 10000,
    rentalDuration: 10
  }
];

const DEFAULT_MEMBERS: Member[] = [
  { id: "mem_1", name: "Danur Wijaya", email: "danurwp70@gmail.com", phone: "081234567890", membershipType: "Premium" },
  { id: "mem_2", name: "Budi Santoso", email: "budi.s@outlook.com", phone: "085678901234", membershipType: "Regular" },
  { id: "mem_3", name: "Siti Rahmawati", email: "rahmasiti@gmail.com", phone: "089876543210", membershipType: "Premium" }
];

const DEFAULT_LOANS: Loan[] = [
  { id: "loan_1", memberId: "mem_1", bookId: "book_1", loanDate: "2026-06-10T09:00:00.000Z", returnDate: "2026-06-13T10:30:00.000Z", status: "Returned", totalFee: 5000 },
  { id: "loan_2", memberId: "mem_1", bookId: "book_3", loanDate: "2026-06-12T11:00:00.000Z", returnDate: null, status: "Active", totalFee: 6000 },
  { id: "loan_3", memberId: "mem_2", bookId: "book_2", loanDate: "2026-06-14T08:00:00.000Z", returnDate: null, status: "Active", totalFee: 8000 }
];

// Helper to read database state
function readDb() {
  try {
    if (!fs.existsSync(DATA_FILE)) {
      const initialDb = {
        authors: DEFAULT_AUTHORS,
        categories: DEFAULT_CATEGORIES,
        books: DEFAULT_BOOKS,
        members: DEFAULT_MEMBERS,
        loans: DEFAULT_LOANS
      };
      fs.writeFileSync(DATA_FILE, JSON.stringify(initialDb, null, 2), "utf-8");
      return initialDb;
    }
    const raw = fs.readFileSync(DATA_FILE, "utf-8");
    return JSON.parse(raw);
  } catch (error) {
    console.error("Gagal membaca database lokal, mereset...", error);
    return {
      authors: DEFAULT_AUTHORS,
      categories: DEFAULT_CATEGORIES,
      books: DEFAULT_BOOKS,
      members: DEFAULT_MEMBERS,
      loans: DEFAULT_LOANS
    };
  }
}

// Helper to write database state
function writeDb(data: any) {
  try {
    fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2), "utf-8");
  } catch (error) {
    console.error("Gagal menulis database lokal", error);
  }
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Body parsers
  app.use(express.json());
  app.use(express.urlencoded({ extended: true }));

  // CORS Simulator middleware
  app.use((req, res, next) => {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept, Authorization");
    res.header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
    if (req.method === "OPTIONS") {
      return res.sendStatus(200);
    }
    next();
  });

  // Bearer Token Authorization guard
  const ADMIN_TOKEN = "mock-jwt-admin-secret-token";

  function requiresAdmin(req: express.Request, res: express.Response, next: express.NextFunction) {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return res.status(401).json({ status: 401, error: "Akses Ditolak: Anda membutuhkan Authorization Bearer Token!" });
    }
    const token = authHeader.split(" ")[1];
    if (token !== ADMIN_TOKEN) {
      return res.status(401).json({ status: 401, error: "Token Kedaluwarsa atau Batil: Sesi admin tidak valid." });
    }
    next();
  }

  // --- API ROUTING PATHS ---

  // 1. AUTHENTICATION ROUTE
  app.post("/api/auth/login", (req, res) => {
    const { username, password } = req.body;
    if (username === "admin" && password === "admin123") {
      return res.json({
        status: 200,
        success: true,
        message: "Autentikasi admin sukses!",
        token: ADMIN_TOKEN,
        user: { username: "admin", role: "admin" }
      });
    }
    return res.status(400).json({ status: 400, success: false, error: "Username atau Password salah!" });
  });

  // 2. BOOKS ROUTES (RESTful CRUD)
  app.get("/api/books", (req, res) => {
    const db = readDb();
    // Hydrate relational data
    const booksWithDetails = db.books.map((b: Book) => {
      const author = db.authors.find((a: Author) => a.id === b.authorId) || { name: "Penulis Tidak Diketahui" };
      const category = db.categories.find((c: Category) => c.id === b.categoryId) || { name: "Kategori Lain" };
      return {
        ...b,
        authorName: author.name,
        categoryName: category.name
      };
    });
    res.json(booksWithDetails);
  });

  app.post("/api/books", requiresAdmin, (req, res) => {
    const db = readDb();
    const { title, authorId, categoryId, coverUrl, description, stock, rentalPrice, rentalDuration } = req.body;
    if (!title || !authorId || !categoryId) {
      return res.status(400).json({ error: "Kolom judul, penulis, dan kategori wajib diisi!" });
    }
    const newBook: Book = {
      id: "book_" + Date.now(),
      title,
      authorId,
      categoryId,
      coverUrl: coverUrl || "https://images.unsplash.com/photo-1543002588-bfa74002ed7e?w=600&auto=format&fit=crop&q=60",
      description: description || "Tidak ada deskripsi tambahan.",
      stock: Number(stock) || 1,
      rentalPrice: Number(rentalPrice) || 3000,
      rentalDuration: Number(rentalDuration) || 3
    };
    db.books.push(newBook);
    writeDb(db);
    res.status(201).json(newBook);
  });

  app.put("/api/books/:id", requiresAdmin, (req, res) => {
    const db = readDb();
    const { id } = req.params;
    const index = db.books.findIndex((b: Book) => b.id === id);
    if (index === -1) {
      return res.status(404).json({ error: "Buku tidak ditemukan!" });
    }
    const { title, authorId, categoryId, coverUrl, description, stock, rentalPrice, rentalDuration } = req.body;
    db.books[index] = {
      ...db.books[index],
      title: title || db.books[index].title,
      authorId: authorId || db.books[index].authorId,
      categoryId: categoryId || db.books[index].categoryId,
      coverUrl: coverUrl !== undefined ? coverUrl : db.books[index].coverUrl,
      description: description !== undefined ? description : db.books[index].description,
      stock: stock !== undefined ? Number(stock) : db.books[index].stock,
      rentalPrice: rentalPrice !== undefined ? Number(rentalPrice) : db.books[index].rentalPrice,
      rentalDuration: rentalDuration !== undefined ? Number(rentalDuration) : db.books[index].rentalDuration
    };
    writeDb(db);
    res.json(db.books[index]);
  });

  app.delete("/api/books/:id", requiresAdmin, (req, res) => {
    const db = readDb();
    const { id } = req.params;
    const index = db.books.findIndex((b: Book) => b.id === id);
    if (index === -1) {
      return res.status(404).json({ error: "Buku tidak ditemukan!" });
    }
    db.books.splice(index, 1);
    writeDb(db);
    res.json({ success: true, message: "Buku berhasil dihapus." });
  });

  // 3. CATEGORIES ROUTES (RESTful CRUD)
  app.get("/api/categories", (req, res) => {
    const db = readDb();
    res.json(db.categories);
  });

  app.post("/api/categories", requiresAdmin, (req, res) => {
    const db = readDb();
    const { name } = req.body;
    if (!name) return res.status(400).json({ error: "Nama kategori wajib diisi!" });
    const newCat: Category = {
      id: "cat_" + Date.now(),
      name,
      slug: name.toLowerCase().replace(/[^a-z0-9]+/g, "-")
    };
    db.categories.push(newCat);
    writeDb(db);
    res.status(201).json(newCat);
  });

  app.put("/api/categories/:id", requiresAdmin, (req, res) => {
    const db = readDb();
    const { id } = req.params;
    const index = db.categories.findIndex((c: Category) => c.id === id);
    if (index === -1) return res.status(404).json({ error: "Kategori tidak ditemukan!" });
    const { name } = req.body;
    db.categories[index].name = name || db.categories[index].name;
    db.categories[index].slug = (name || db.categories[index].name).toLowerCase().replace(/[^a-z0-9]+/g, "-");
    writeDb(db);
    res.json(db.categories[index]);
  });

  app.delete("/api/categories/:id", requiresAdmin, (req, res) => {
    const db = readDb();
    const { id } = req.params;
    const index = db.categories.findIndex((c: Category) => c.id === id);
    if (index === -1) return res.status(404).json({ error: "Kategori tidak ditemukan!" });
    // Check if category is used in any books
    const anyUsage = db.books.some((b: Book) => b.categoryId === id);
    if (anyUsage) return res.status(400).json({ error: "Gagal: Kategori masih digunakan oleh beberapa buku master!" });
    db.categories.splice(index, 1);
    writeDb(db);
    res.json({ success: true, message: "Kategori berhasil dihapus." });
  });

  // 4. AUTHORS ROUTES (RESTful CRUD)
  app.get("/api/authors", (req, res) => {
    const db = readDb();
    res.json(db.authors);
  });

  app.post("/api/authors", requiresAdmin, (req, res) => {
    const db = readDb();
    const { name, bio } = req.body;
    if (!name) return res.status(400).json({ error: "Nama penulis wajib diisi!" });
    const newAuthor: Author = {
      id: "auth_" + Date.now(),
      name,
      bio: bio || "Tidak ada profil biografi tambahan."
    };
    db.authors.push(newAuthor);
    writeDb(db);
    res.status(201).json(newAuthor);
  });

  app.put("/api/authors/:id", requiresAdmin, (req, res) => {
    const db = readDb();
    const { id } = req.params;
    const index = db.authors.findIndex((a: Author) => a.id === id);
    if (index === -1) return res.status(404).json({ error: "Penulis tidak ditemukan!" });
    const { name, bio } = req.body;
    db.authors[index].name = name || db.authors[index].name;
    db.authors[index].bio = bio !== undefined ? bio : db.authors[index].bio;
    writeDb(db);
    res.json(db.authors[index]);
  });

  app.delete("/api/authors/:id", requiresAdmin, (req, res) => {
    const db = readDb();
    const { id } = req.params;
    const index = db.authors.findIndex((a: Author) => a.id === id);
    if (index === -1) return res.status(404).json({ error: "Penulis tidak ditemukan!" });
    const anyUsage = db.books.some((b: Book) => b.authorId === id);
    if (anyUsage) return res.status(400).json({ error: "Gagal: Penulis masih digunakan oleh beberapa buku master!" });
    db.authors.splice(index, 1);
    writeDb(db);
    res.json({ success: true, message: "Penulis berhasil dihapus." });
  });

  // 5. MEMBERS ROUTES (RESTful CRUD)
  app.get("/api/members", (req, res) => {
    const db = readDb();
    res.json(db.members);
  });

  app.post("/api/members", requiresAdmin, (req, res) => {
    const db = readDb();
    const { name, email, phone, membershipType } = req.body;
    if (!name || !email) return res.status(400).json({ error: "Nama dan Email anggota wajib diisi!" });
    const newMember: Member = {
      id: "mem_" + Date.now(),
      name,
      email,
      phone: phone || "-",
      membershipType: membershipType === "Premium" ? "Premium" : "Regular"
    };
    db.members.push(newMember);
    writeDb(db);
    res.status(201).json(newMember);
  });

  app.put("/api/members/:id", requiresAdmin, (req, res) => {
    const db = readDb();
    const { id } = req.params;
    const index = db.members.findIndex((m: Member) => m.id === id);
    if (index === -1) return res.status(404).json({ error: "Anggota tidak ditemukan!" });
    const { name, email, phone, membershipType } = req.body;
    db.members[index] = {
      ...db.members[index],
      name: name || db.members[index].name,
      email: email || db.members[index].email,
      phone: phone !== undefined ? phone : db.members[index].phone,
      membershipType: membershipType !== undefined ? membershipType : db.members[index].membershipType
    };
    writeDb(db);
    res.json(db.members[index]);
  });

  app.delete("/api/members/:id", requiresAdmin, (req, res) => {
    const db = readDb();
    const { id } = req.params;
    const index = db.members.findIndex((m: Member) => m.id === id);
    if (index === -1) return res.status(404).json({ error: "Anggota tidak ditemukan!" });
    // Check if member has active loans
    const hasActiveLoans = db.loans.some((l: Loan) => l.memberId === id && l.status === "Active");
    if (hasActiveLoans) {
      return res.status(400).json({ error: "Gagal: Anggota ini sedang memiliki status peminjaman buku yang aktif!" });
    }
    db.members.splice(index, 1);
    writeDb(db);
    res.json({ success: true, message: "Anggota berhasil dihapus." });
  });

  // 6. LOANS ROUTES (RESTful CRUD & State Transitions)
  app.get("/api/loans", (req, res) => {
    const db = readDb();
    // Hydrate relational context for convenient frontend display
    const loansDetails = db.loans.map((l: Loan) => {
      const book = db.books.find((b: Book) => b.id === l.bookId);
      const member = db.members.find((m: Member) => m.id === l.memberId);
      return {
        ...l,
        bookTitle: book ? book.title : "Buku Telah Dihapus",
        memberName: member ? member.name : "Anggota Telah Dihapus",
        rentalPrice: book ? book.rentalPrice : 0
      };
    });
    res.json(loansDetails);
  });

  app.post("/api/loans", requiresAdmin, (req, res) => {
    const db = readDb();
    const { memberId, bookId } = req.body;
    if (!memberId || !bookId) {
      return res.status(400).json({ error: "Pilih Anggota dan Buku yang akan dipinjam!" });
    }
    // Verify book stock
    const bookIndex = db.books.findIndex((b: Book) => b.id === bookId);
    if (bookIndex === -1) return res.status(404).json({ error: "Buku tidak ditemukan!" });
    if (db.books[bookIndex].stock <= 0) {
      return res.status(400).json({ error: "Stok buku saat ini kosong! Tidak dapat melakukan rental." });
    }

    // Decrement stock
    db.books[bookIndex].stock -= 1;

    const newLoan: Loan = {
      id: "loan_" + Date.now(),
      memberId,
      bookId,
      loanDate: new Date().toISOString(),
      returnDate: null,
      status: "Active",
      totalFee: db.books[bookIndex].rentalPrice
    };

    db.loans.push(newLoan);
    writeDb(db);
    res.status(201).json(newLoan);
  });

  // Action: Return a book (updates status to 'Returned' and returns stock)
  app.post("/api/loans/:id/return", requiresAdmin, (req, res) => {
    const db = readDb();
    const { id } = req.params;
    const index = db.loans.findIndex((l: Loan) => l.id === id);
    if (index === -1) return res.status(404).json({ error: "Peminjaman tidak ditemukan!" });
    if (db.loans[index].status === "Returned") {
      return res.status(400).json({ error: "Peminjaman ini sudah dikembalikan sebelumnya!" });
    }

    db.loans[index].status = "Returned";
    db.loans[index].returnDate = new Date().toISOString();

    // Increment stock of the book back
    const bookIndex = db.books.findIndex((b: Book) => b.id === db.loans[index].bookId);
    if (bookIndex !== -1) {
      db.books[bookIndex].stock += 1;
    }

    writeDb(db);
    res.json(db.loans[index]);
  });

  app.delete("/api/loans/:id", requiresAdmin, (req, res) => {
    const db = readDb();
    const { id } = req.params;
    const index = db.loans.findIndex((l: Loan) => l.id === id);
    if (index === -1) return res.status(404).json({ error: "Peminjaman tidak ditemukan!" });
    
    // If deleted while active, restore stock
    if (db.loans[index].status === "Active") {
      const bookIndex = db.books.findIndex((b: Book) => b.id === db.loans[index].bookId);
      if (bookIndex !== -1) {
        db.books[bookIndex].stock += 1;
      }
    }

    db.loans.splice(index, 1);
    writeDb(db);
    res.json({ success: true, message: "Peminjaman berhasil dihapus." });
  });

  // 7. DASHBOARD DATA OVERVIEW (For main stats charts & totals)
  app.get("/api/dashboard/stats", (req, res) => {
    const db = readDb();
    const totalBooks = db.books.reduce((acc: number, b: Book) => acc + b.stock, 0);
    const totalMembers = db.members.length;
    const totalActiveLoans = db.loans.filter((l: Loan) => l.status === "Active").length;
    const totalEarnings = db.loans.reduce((acc: number, l: Loan) => acc + l.totalFee, 0);

    // Distribution by Category
    const categoryDistribution = db.categories.map((cat: Category) => {
      const count = db.books.filter((b: Book) => b.categoryId === cat.id).length;
      return { name: cat.name, count };
    });

    // Recent Loans
    const recentLoans = db.loans.slice(-5).reverse().map((l: Loan) => {
      const book = db.books.find((b: Book) => b.id === l.bookId);
      const member = db.members.find((m: Member) => m.id === l.memberId);
      return {
        ...l,
        bookTitle: book ? book.title : "Buku Terhapus",
        memberName: member ? member.name : "Anggota Terhapus"
      };
    });

    res.json({
      totalBooks,
      totalMembers,
      totalActiveLoans,
      totalEarnings,
      categoryDistribution,
      recentLoans
    });
  });

  // Seed / Reset Database endpoint
  app.post("/api/admin/reset-db", requiresAdmin, (req, res) => {
    const initialDb = {
      authors: DEFAULT_AUTHORS,
      categories: DEFAULT_CATEGORIES,
      books: DEFAULT_BOOKS,
      members: DEFAULT_MEMBERS,
      loans: DEFAULT_LOANS
    };
    writeDb(initialDb);
    res.json({ success: true, message: "Database kembali di-seeding ke data bawaan!" });
  });

  // --- VITE DEV SERVER OR STATIC PRODUCTION BUILD HANDLER ---

  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[E-LIBRARY RUNNING] Server up and listening on port ${PORT}`);
  });
}

startServer();
