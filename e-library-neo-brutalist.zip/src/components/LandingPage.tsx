import React, { useState, useEffect } from 'react';
import { Book, Category, Author } from '../types';
import { api } from '../api';
import { NeoCard, NeoButton, NeoBadge, NeoInput, NeoSelect } from './NeoBrutalist';
import { Search, BookOpen, Layers, ShieldAlert, Award, ArrowRight, UserCheck, RefreshCw } from 'lucide-react';
import { motion } from 'motion/react';

interface LandingPageProps {
  onOpenLogin: () => void;
  isAdmin: boolean;
  onGoToAdmin: () => void;
  triggerToast: (msg: string, type: 'success' | 'warn' | 'error' | 'info') => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({
  onOpenLogin,
  isAdmin,
  onGoToAdmin,
  triggerToast
}) => {
  const [books, setBooks] = useState<Book[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [authors, setAuthors] = useState<Author[]>([]);
  const [loading, setLoading] = useState(true);
  
  // Search and filter states
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedAuthor, setSelectedAuthor] = useState('all');
  const [onlyAvailable, setOnlyAvailable] = useState(false);

  // Selected book for details popup modal
  const [selectedBook, setSelectedBook] = useState<(Book & { authorName?: string; categoryName?: string }) | null>(null);

  const fetchCatalogData = async () => {
    setLoading(true);
    try {
      const [booksList, categoriesList, authorsList] = await Promise.all([
        api.books.list(),
        api.categories.list(),
        api.authors.list()
      ]);
      setBooks(booksList);
      setCategories(categoriesList);
      setAuthors(authorsList);
    } catch (error) {
      console.error(error);
      triggerToast("Gagal mengambil data katalog dari API server.", "error");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCatalogData();
  }, []);

  // Filter books logical pipeline
  const filteredBooks = books.filter(book => {
    // 1. Text Search
    const matchesSearch = 
      book.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      book.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (book as any).authorName?.toLowerCase().includes(searchQuery.toLowerCase());

    // 2. Category Filter
    const matchesCategory = selectedCategory === 'all' || book.categoryId === selectedCategory;

    // 3. Author Filter
    const matchesAuthor = selectedAuthor === 'all' || book.authorId === selectedAuthor;

    // 4. Stock Availability Filter
    const matchesStock = !onlyAvailable || book.stock > 0;

    return matchesSearch && matchesCategory && matchesAuthor && matchesStock;
  });

  // Calculate some simple dashboard metrics to display on the public ribbon
  const totalBookCount = books.length;
  const availableStockSum = books.reduce((sum, b) => sum + (b.stock > 0 ? b.stock : 0), 0);
  const outOfStockCount = books.filter(b => b.stock === 0).length;

  return (
    <div className="space-y-10">
      {/* 1. HERO HEADER AREA */}
      <div className="relative neo-border-thick bg-neo-yellow p-6 md:p-10 shadow-[6px_6px_0px_0px_#000000] rotate-[-0.5deg]">
        <div className="absolute top-2 right-2 md:top-4 md:right-4 font-mono text-[10px] md:text-xs bg-black text-white px-2 py-0.5 uppercase tracking-wider neo-border-thin">
          RESTful decoupled system
        </div>
        
        <div className="max-w-3xl space-y-4">
          <NeoBadge color="magenta" className="text-sm px-3 py-1">WEB PROGRAMMIMNG 2 UAS</NeoBadge>
          <h1 className="font-display font-black text-3xl md:text-5xl lg:text-6xl uppercase tracking-tighter leading-none text-black mt-2">
            KOMIK & BUKU DIGITAL <br />
            <span className="bg-white px-2 italic neo-border-thin shadow-[2px_2px_0px_#000]">RENTAL PORTAL</span>
          </h1>
          <p className="font-mono text-xs md:text-sm text-black font-medium leading-relaxed max-w-2xl bg-white/70 p-3 neo-border-thin">
            Aplikasi sirkulasi buku digital dengan performa tinggi. Rasakan antarmuka <b>Neo-Brutalist</b> yang responsif, terintegrasi penuh dengan <b>REST API Server</b> menggunakan interseptor token siber dan basis data persisten.
          </p>
          
          <div className="flex flex-wrap gap-3 pt-2">
            {isAdmin ? (
              <NeoButton variant="magenta" onClick={onGoToAdmin}>
                Masuk Dashboard Admin <ArrowRight className="w-4 h-4 ml-2" />
              </NeoButton>
            ) : (
              <NeoButton variant="black" onClick={onOpenLogin}>
                Login Administrator <ShieldAlert className="w-4 h-4 ml-2" />
              </NeoButton>
            )}
            <NeoButton variant="white" onClick={fetchCatalogData} className="w-10 h-10 p-0" title="Sinkronkan data API">
              <RefreshCw className="w-4 h-4 text-black" />
            </NeoButton>
          </div>
        </div>
      </div>

      {/* 2. STATS RIBBON BANNER */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <NeoCard accentColor="teal" className="p-4" shadow={true}>
          <div className="flex items-center gap-3">
            <div className="bg-neo-teal p-2.5 neo-border-thin">
              <BookOpen className="w-5 h-5 text-black" />
            </div>
            <div>
              <p className="font-mono text-[10px] text-zinc-600 uppercase font-black">Total Publikasi</p>
              <h3 className="font-display font-black text-2xl text-black">{totalBookCount}</h3>
            </div>
          </div>
        </NeoCard>

        <NeoCard accentColor="magenta" className="p-4" shadow={true}>
          <div className="flex items-center gap-3">
            <div className="bg-neo-magenta p-2.5 neo-border-thin text-white">
              <Layers className="w-5 h-5 text-white" />
            </div>
            <div>
              <p className="font-mono text-[10px] text-zinc-600 uppercase font-black">Kategori</p>
              <h3 className="font-display font-black text-2xl text-black">{categories.length}</h3>
            </div>
          </div>
        </NeoCard>

        <NeoCard accentColor="green" className="p-4" shadow={true}>
          <div className="flex items-center gap-3">
            <div className="bg-neo-green p-2.5 neo-border-thin text-white">
              <UserCheck className="w-5 h-5 text-white" />
            </div>
            <div>
              <p className="font-mono text-[10px] text-zinc-600 uppercase font-black">Penulis Terdaftar</p>
              <h3 className="font-display font-black text-2xl text-black">{authors.length}</h3>
            </div>
          </div>
        </NeoCard>

        <NeoCard accentColor="orange" className="p-4" shadow={true}>
          <div className="flex items-center gap-3">
            <div className="bg-neo-orange p-2.5 neo-border-thin text-white">
              <Award className="w-5 h-5 text-white" />
            </div>
            <div>
              <p className="font-mono text-[10px] text-zinc-600 uppercase font-black">Unit Tersedia</p>
              <h3 className="font-display font-black text-2xl text-black">{availableStockSum} <span className="text-[10px] text-zinc-700 font-mono">buku</span></h3>
            </div>
          </div>
        </NeoCard>
      </div>

      {/* 3. CATALOGUE FILTERS & BENTO LISTS */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8 items-start">
        {/* LEFT: FILTER CONTROLS CARD */}
        <div className="lg:sticky lg:top-4 z-10">
          <NeoCard headerText="PANEL FILTER KATALOG" headerAccent="bg-neo-teal" shadow={true} className="space-y-4">
            <div className="relative">
              <NeoInput
                label="Cari Buku / Komik"
                placeholder="Judul, penulis, deskripsi..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              <Search className="absolute right-3 top-[37px] w-4 h-4 text-zinc-500" />
            </div>

            <NeoSelect
              label="Filter Kategori"
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              options={[
                { value: 'all', label: '📖 Semua Kategori' },
                ...categories.map(c => ({ value: c.id, label: `👉 ${c.name}` }))
              ]}
            />

            <NeoSelect
              label="Filter Penulis"
              value={selectedAuthor}
              onChange={(e) => setSelectedAuthor(e.target.value)}
              options={[
                { value: 'all', label: '✍️ Semua Penulis' },
                ...authors.map(a => ({ value: a.id, label: `✏️ ${a.name}` }))
              ]}
            />

            <div className="pt-2 border-t-2 border-black">
              <label className="flex items-start gap-2.5 cursor-pointer group mt-2">
                <input
                  type="checkbox"
                  checked={onlyAvailable}
                  onChange={(e) => setOnlyAvailable(e.target.checked)}
                  className="w-5 h-5 neo-border cursor-pointer appearance-none checked:bg-neo-magenta checked:after:content-['✓'] checked:after:text-white checked:after:flex checked:after:justify-center checked:after:text-sm select-none"
                />
                <span className="font-display font-bold text-xs md:text-sm text-black select-none group-hover:text-neo-magenta transition-colors">
                  Hanya Stok Tersedia ({books.filter(b => b.stock > 0).length})
                </span>
              </label>
            </div>

            {/* QUICK SEED ACCENT CARD */}
            <div className="bg-neo-beige p-3 neo-border border-dashed text-black mt-4">
              <p className="font-mono text-[9px] uppercase font-black mb-1">Butuh data awal?</p>
              <p className="font-mono text-[10px] text-zinc-700 leading-tight">
                Gunakan menu reset database di admin dashboard untuk memulihkan isi default perpustakaan secara instan.
              </p>
            </div>
          </NeoCard>
        </div>

        {/* RIGHT: BENTO BOOKS LISTING */}
        <div className="lg:col-span-3 space-y-6">
          <div className="flex items-center justify-between border-b-4 border-black pb-2 bg-white p-3 neo-border shadow-[3px_3px_0px_#000]">
            <div>
              <h2 className="font-display font-black text-xl md:text-2xl uppercase tracking-tighter text-black">
                MENCARI DAN MEMBACA ({filteredBooks.length} buku cocok)
              </h2>
              <p className="font-mono text-xs text-zinc-500">Menerapkan pencarian instan klien terdekopel.</p>
            </div>
            
            <div className="flex gap-2">
              <span className="w-3 h-3 rounded-full bg-neo-yellow neo-border-thin"></span>
              <span className="w-3 h-3 rounded-full bg-neo-magenta neo-border-thin"></span>
              <span className="w-3 h-3 rounded-full bg-neo-teal neo-border-thin"></span>
            </div>
          </div>

          {loading ? (
            <div className="flex flex-col items-center justify-center p-20 bg-white neo-border shadow-[4px_4px_0px_0px_#000000]">
              <div className="animate-spin rounded-none w-10 h-10 border-4 border-black border-t-neo-magenta mb-4"></div>
              <p className="font-display font-bold text-base text-black uppercase tracking-wider">MENGAMBIL DATA DARI REST SERVER...</p>
              <p className="font-mono text-xs text-zinc-500 mt-1">Harap tunggu, server CodeIgniter 4 mock Anda sedang dihubungi.</p>
            </div>
          ) : filteredBooks.length === 0 ? (
            <div className="p-16 text-center bg-white neo-border-thick shadow-[6px_6px_0px_0px_#000000] space-y-4">
              <span className="inline-block text-5xl">🔍</span>
              <h3 className="font-display font-black text-xl md:text-2xl uppercase text-black">Buku Tidak Ditemukan!</h3>
              <p className="font-mono text-xs text-zinc-500 max-w-md mx-auto">
                Silahkan ganti kata kunci pencarian Anda atau reset filter kategori / penulis di kolom samping kiri.
              </p>
              <NeoButton variant="teal" size="sm" onClick={() => {
                setSearchQuery('');
                setSelectedCategory('all');
                setSelectedAuthor('all');
                setOnlyAvailable(false);
              }}>
                Hapus Semua Filter
              </NeoButton>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-6">
              {filteredBooks.map((book) => {
                const bookCategory = categories.find(c => c.id === book.categoryId)?.name || 'Kategori Umum';
                const bookAuthor = authors.find(a => a.id === book.authorId)?.name || 'Penulis Misterius';

                return (
                  <motion.div
                    key={book.id}
                    layout
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ duration: 0.2 }}
                    className="flex flex-col bg-white neo-border-thick text-black relative shadow-[4px_4px_0px_0px_#000000] hover:shadow-[7px_7px_0px_0px_#000000] hover:-translate-x-1 hover:-translate-y-1 transition-all h-full"
                  >
                    {/* Cover Frame */}
                    <div className="relative aspect-video w-full bg-zinc-200 border-b-2 border-black overflow-hidden group">
                      <img
                        src={book.coverUrl}
                        alt={book.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute top-2 left-2 flex flex-col gap-1.5 items-start">
                        <NeoBadge color="magenta">{bookCategory}</NeoBadge>
                        <NeoBadge color="teal">{bookAuthor}</NeoBadge>
                      </div>

                      <div className="absolute bottom-2 right-2">
                        <span className="bg-black text-white text-xs font-mono font-bold px-2.5 py-1 neo-border shadow-[1.5px_1.5px_0px_var(--color-neo-yellow)]">
                          Rp {book.rentalPrice.toLocaleString('id-ID')} / hari
                        </span>
                      </div>
                    </div>

                    {/* Meta Card Description */}
                    <div className="p-4 flex-1 flex flex-col justify-between space-y-4">
                      <div className="space-y-2">
                        <h3 className="font-display font-black text-lg text-black hover:text-neo-magenta cursor-pointer line-clamp-1" title={book.title} onClick={() => setSelectedBook({ ...book, authorName: bookAuthor, categoryName: bookCategory })}>
                          {book.title}
                        </h3>
                        <p className="font-sans text-xs text-zinc-600 line-clamp-3">
                          {book.description}
                        </p>
                      </div>

                      <div className="flex items-center justify-between pt-3 border-t-2 border-black">
                        <div className="font-mono text-xs flex flex-col">
                          <span className="font-black text-[10px] text-zinc-500 uppercase">Stok Tersedia</span>
                          <span className={`font-bold mt-0.5 ${book.stock > 0 ? 'text-neo-green font-black' : 'text-neo-orange font-black'}`}>
                            {book.stock} unit {book.stock === 0 && '(Habis!)'}
                          </span>
                        </div>

                        <NeoButton
                          variant={book.stock > 0 ? 'yellow' : 'white'}
                          size="sm"
                          onClick={() => setSelectedBook({ ...book, authorName: bookAuthor, categoryName: bookCategory })}
                        >
                          Lihat Detail
                        </NeoButton>
                      </div>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* 4. SELECTION DETAILS POPUP OVERLAY */}
      {selectedBook && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="fixed inset-0 bg-black/60 backdrop-blur-xs" onClick={() => setSelectedBook(null)} />
          <motion.div
            initial={{ scale: 0.9, y: 40, opacity: 0 }}
            animate={{ scale: 1, y: 0, opacity: 1 }}
            className="z-10 bg-white neo-border-thick shadow-[8px_8px_0px_#000] w-full max-w-2xl p-6 relative max-h-[85vh] overflow-y-auto"
          >
            {/* Header decoration */}
            <div className="flex items-center justify-between border-b-2 border-black pb-3 mb-4">
              <NeoBadge color="magenta">DETAIL BUKU DIGITAL</NeoBadge>
              <button
                onClick={() => setSelectedBook(null)}
                className="neo-border bg-neo-yellow px-2.5 py-1 font-display font-bold text-xs hover:bg-[#ffed4a] transition-all cursor-pointer shadow-[1.5px_1.5px_0px_#000]"
              >
                TUTUP (X)
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Cover visualizer */}
              <div className="space-y-3">
                <div className="neo-border w-full aspect-3/4 overflow-hidden shadow-[4px_4px_0px_#000]">
                  <img
                    src={selectedBook.coverUrl}
                    alt={selectedBook.title}
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                </div>
                <div className="bg-neo-beige p-3 neo-border text-center">
                  <p className="font-mono text-[10px] text-zinc-500 uppercase font-black">Biaya Sewa / Rental</p>
                  <p className="font-display font-black text-lg text-black">Rp {selectedBook.rentalPrice.toLocaleString('id-ID')} <span className="text-xs font-mono font-medium">/ 24 Jam</span></p>
                </div>
              </div>

              {/* Title & Metadata */}
              <div className="space-y-4 flex flex-col justify-between">
                <div className="space-y-3">
                  <h2 className="font-display font-black text-2xl leading-tight text-black border-b-2 border-black pb-2">
                    {selectedBook.title}
                  </h2>
                  
                  <div className="grid grid-cols-2 gap-2">
                    <div className="neo-border bg-amber-50/20 p-2 text-xs font-mono">
                      <span className="block text-zinc-500 text-[10px] uppercase font-bold">Kategori</span>
                      <span className="font-bold text-black">{selectedBook.categoryName}</span>
                    </div>
                    <div className="neo-border bg-amber-50/20 p-2 text-xs font-mono">
                      <span className="block text-zinc-500 text-[10px] uppercase font-bold">Penulis</span>
                      <span className="font-bold text-black">{selectedBook.authorName}</span>
                    </div>
                    <div className="neo-border bg-amber-50/20 p-2 text-xs font-mono">
                      <span className="block text-zinc-500 text-[10px] uppercase font-bold">Batas Rental</span>
                      <span className="font-bold text-black">{selectedBook.rentalDuration} Hari Maks.</span>
                    </div>
                    <div className="neo-border bg-amber-50/20 p-2 text-xs font-mono">
                      <span className="block text-zinc-500 text-[10px] uppercase font-bold">Status Stok</span>
                      <span className={`font-bold ${selectedBook.stock > 0 ? 'text-green-600' : 'text-red-600'}`}>
                        {selectedBook.stock > 0 ? `${selectedBook.stock} Unit` : 'Habis'}
                      </span>
                    </div>
                  </div>

                  <div className="space-y-1">
                    <span className="font-display font-bold text-xs text-zinc-800 uppercase block">Sinopsis / Ringkasan</span>
                    <p className="font-sans text-xs text-zinc-700 leading-relaxed max-h-40 overflow-y-auto bg-neo-beige p-2 neo-border-thin">
                      {selectedBook.description}
                    </p>
                  </div>
                </div>

                <div className="pt-4 border-t-2 border-black space-y-2">
                  <div className="flex gap-2">
                    {selectedBook.stock > 0 ? (
                      <NeoBadge color="green" className="w-full text-center py-1">READY FOR DIGITAL DISTRIBUTION</NeoBadge>
                    ) : (
                      <NeoBadge color="orange" className="w-full text-center py-1">OUT OF STOCK IN LIBRARY</NeoBadge>
                    )}
                  </div>
                  <p className="font-mono text-[9px] text-zinc-500 text-center leading-tight">
                    *Proses sewa/rental mandiri hanya tersedia untuk Anggota yang terdaftar oleh Administrator. Hubungi pustakawan admin untuk melakukan rental buku ini.
                  </p>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
};
