import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, CheckCircle, AlertTriangle, Info } from 'lucide-react';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'yellow' | 'magenta' | 'teal' | 'orange' | 'green' | 'white' | 'black';
  size?: 'sm' | 'md' | 'lg';
  shadow?: boolean;
}

export const NeoButton: React.FC<ButtonProps> = ({
  children,
  variant = 'yellow',
  size = 'md',
  shadow = true,
  className = '',
  ...props
}) => {
  const baseStyles = 'inline-flex items-center justify-center font-display font-bold neo-border text-black transition-all rounded-none cursor-pointer select-none';
  
  const variants = {
    yellow: 'bg-neo-yellow hover:bg-[#ffed4a]',
    magenta: 'bg-neo-magenta hover:bg-[#ff33ff] text-white',
    teal: 'bg-neo-teal hover:bg-[#33d0d8]',
    orange: 'bg-neo-orange hover:bg-[#ff692a] text-white',
    green: 'bg-neo-green hover:bg-[#47d16d] text-white',
    white: 'bg-white hover:bg-gray-100',
    black: 'bg-black text-white hover:bg-zinc-800 border-white',
  };

  const sizes = {
    sm: 'text-xs px-3 py-1.5',
    md: 'text-sm px-5 py-2.5',
    lg: 'text-base px-7 py-3 py-4',
  };

  const shadowStyle = shadow 
    ? 'shadow-[3px_3px_0px_#000000] hover:shadow-[5px_5px_0px_#000000] hover:-translate-x-0.5 hover:-translate-y-0.5 active:shadow-[1px_1px_0px_#000000] active:translate-x-0.5 active:translate-y-0.5' 
    : '';

  return (
    <button
      className={`${baseStyles} ${variants[variant]} ${sizes[size]} ${shadowStyle} ${className}`}
      {...props}
    >
      {children}
    </button>
  );
};

interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
  accentColor?: 'yellow' | 'magenta' | 'teal' | 'orange' | 'green' | 'none';
  headerText?: string;
  headerAccent?: string;
  shadow?: boolean;
}

export const NeoCard: React.FC<CardProps> = ({
  children,
  accentColor = 'none',
  headerText,
  headerAccent,
  shadow = true,
  className = '',
  ...props
}) => {
  const accents = {
    yellow: 'border-t-[8px] border-t-neo-yellow',
    magenta: 'border-t-[8px] border-t-neo-magenta',
    teal: 'border-t-[8px] border-t-neo-teal',
    orange: 'border-t-[8px] border-t-neo-orange',
    green: 'border-t-[8px] border-t-neo-green',
    none: '',
  };

  const shadowStyle = shadow ? 'shadow-[6px_6px_0px_0px_#000000]' : '';

  return (
    <div
      className={`bg-white neo-border text-black p-5 relative rounded-none ${accents[accentColor]} ${shadowStyle} ${className}`}
      {...props}
    >
      {headerText && (
        <div className={`-mt-5 -mx-5 px-5 py-3 border-b-2 border-black font-display font-black text-lg flex items-center justify-between ${headerAccent || 'bg-neo-beige'}`}>
          <span>{headerText}</span>
        </div>
      )}
      <div className={headerText ? 'pt-4' : ''}>
        {children}
      </div>
    </div>
  );
};

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
}

export const NeoInput: React.FC<InputProps> = ({
  label,
  error,
  className = '',
  ...props
}) => {
  return (
    <div className="flex flex-col w-full mb-4">
      {label && (
        <label className="font-display font-bold text-black text-sm mb-1.5 tracking-tight flex items-center">
          {label}
        </label>
      )}
      <input
        className={`w-full bg-white neo-border p-2.5 font-mono text-sm rounded-none outline-none focus:ring-2 focus:ring-black focus:bg-amber-50/20 text-black placeholder-zinc-500 transition-all ${
          error ? 'border-red-600 ring-2 ring-red-300' : ''
        } ${className}`}
        {...props}
      />
      {error && <span className="text-xs font-bold text-red-600 mt-1 font-mono">{error}</span>}
    </div>
  );
};

interface SelectProps extends React.SelectHTMLAttributes<HTMLSelectElement> {
  label?: string;
  error?: string;
  options: { value: string; label: string }[];
}

export const NeoSelect: React.FC<SelectProps> = ({
  label,
  error,
  options,
  className = '',
  ...props
}) => {
  return (
    <div className="flex flex-col w-full mb-4">
      {label && (
        <label className="font-display font-medium text-black text-sm mb-1.5 tracking-tight">
          {label}
        </label>
      )}
      <div className="relative">
        <select
          className={`w-full bg-white neo-border p-2.5 font-mono text-sm rounded-none outline-none appearance-none focus:ring-2 focus:ring-black text-black cursor-pointer transition-all ${
            error ? 'border-red-600' : ''
          } ${className}`}
          {...props}
        >
          {options.map((opt) => (
            <option key={opt.value} value={opt.value}>
              {opt.label}
            </option>
          ))}
        </select>
        <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-4 border-l-2 border-black bg-neo-yellow text-black">
          ▼
        </div>
      </div>
      {error && <span className="text-xs font-bold text-red-600 mt-1 font-mono">{error}</span>}
    </div>
  );
};

interface BadgeProps {
  children: React.ReactNode;
  color?: 'yellow' | 'magenta' | 'teal' | 'orange' | 'green' | 'gray' | 'purple';
  variant?: 'solid' | 'subtle';
  className?: string;
}

export const NeoBadge: React.FC<BadgeProps> = ({
  children,
  color = 'yellow',
  className = '',
}) => {
  const colors = {
    yellow: 'bg-neo-yellow text-black',
    magenta: 'bg-neo-magenta text-white',
    teal: 'bg-neo-teal text-black',
    orange: 'bg-neo-orange text-white',
    green: 'bg-neo-green text-white',
    gray: 'bg-white text-black',
    purple: 'bg-[#9b59b6] text-white',
  };

  return (
    <span className={`inline-block font-mono font-bold px-2 py-0.5 text-xs neo-border-thin shadow-[1.5px_1.5px_0px_#000000] rotate-[-1deg] select-none ${colors[color]} ${className}`}>
      {children}
    </span>
  );
};

interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  children: React.ReactNode;
  accentColor?: 'yellow' | 'magenta' | 'teal' | 'orange' | 'green';
}

export const NeoModal: React.FC<ModalProps> = ({
  isOpen,
  onClose,
  title,
  children,
  accentColor = 'teal',
}) => {
  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/60 backdrop-blur-xs"
            onClick={onClose}
          />
          <motion.div
            initial={{ scale: 0.9, y: 30, opacity: 0 }}
            animate={{ scale: 1, y: 0, opacity: 1 }}
            exit={{ scale: 0.9, y: 30, opacity: 0 }}
            transition={{ type: 'spring', damping: 20, stiffness: 300 }}
            className="z-10 w-full max-w-xl"
          >
            <NeoCard
              accentColor={accentColor}
              shadow={true}
              className="neo-shadow-lg"
            >
              <div className="flex items-center justify-between border-b-2 border-black pb-3 -mt-1 -mx-1 mb-4">
                <h3 className="font-display font-black text-xl tracking-tight text-black">{title}</h3>
                <button
                  onClick={onClose}
                  className="neo-border-thin bg-neo-yellow p-1 hover:bg-[#ffed4a] transition-colors cursor-pointer"
                >
                  <X className="w-5 h-5 text-black" />
                </button>
              </div>
              <div className="max-h-[70vh] overflow-y-auto pr-1">
                {children}
              </div>
            </NeoCard>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

export type ToastType = 'success' | 'warn' | 'error' | 'info';

export interface ToastItem {
  id: string;
  message: string;
  type: ToastType;
}

interface ToastProps {
  toasts: ToastItem[];
  removeToast: (id: string) => void;
}

export const NeoToastStack: React.FC<ToastProps> = ({ toasts, removeToast }) => {
  const getBannerColor = (type: ToastType) => {
    switch (type) {
      case 'success': return 'bg-neo-green';
      case 'warn': return 'bg-neo-yellow';
      case 'error': return 'bg-neo-orange';
      case 'info': return 'bg-neo-teal';
    }
  };

  const getIcon = (type: ToastType) => {
    switch (type) {
      case 'success': return <CheckCircle className="w-4 h-4 mr-2 text-white shrink-0" />;
      case 'warn': return <AlertTriangle className="w-4 h-4 mr-2 text-black shrink-0" />;
      case 'error': return <X className="w-4 h-4 mr-2 text-white shrink-0" />;
      case 'info': return <Info className="w-4 h-4 mr-2 text-black shrink-0" />;
    }
  };

  const getTextColor = (type: ToastType) => {
    return (type === 'warn' || type === 'info') ? 'text-black' : 'text-white';
  };

  return (
    <div className="fixed bottom-5 right-5 z-50 flex flex-col gap-3 max-w-[90vw] md:max-w-md pointer-events-none">
      <AnimatePresence>
        {toasts.map((toast) => (
          <motion.div
            key={toast.id}
            initial={{ opacity: 0, x: 50, scale: 0.9 }}
            animate={{ opacity: 1, x: 0, scale: 1 }}
            exit={{ opacity: 0, x: 50, scale: 0.9 }}
            className={`pointer-events-auto flex items-center justify-between p-3.5 neo-border shadow-[3px_3px_0px_#000000] rounded-none ${getBannerColor(toast.type)} ${getTextColor(toast.type)}`}
          >
            <div className="flex items-center font-display font-bold text-xs md:text-sm">
              {getIcon(toast.type)}
              <span>{toast.message}</span>
            </div>
            <button
              onClick={() => removeToast(toast.id)}
              className={`ml-4 cursor-pointer focus:outline-none p-0.5 border border-transparent hover:border-black ${getTextColor(toast.type)}`}
            >
              <X className="w-4 h-4" />
            </button>
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
};
