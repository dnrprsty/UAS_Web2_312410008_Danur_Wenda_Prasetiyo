import React, { useState, useEffect } from 'react';
import { Book, Category, Author, Member, Loan } from '../types';
import { api } from '../api';
import { NeoCard, NeoButton, NeoInput, NeoBadge, NeoSelect, NeoModal } from './NeoBrutalist';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';
import { 
  BookOpen, Layers, Users, RefreshCw, Plus, 
  Trash2, Edit, CheckCircle, Database, LogOut, 
  Search, ClipboardList, Wallet, FileSpreadsheet, PlusCircle 
} from 'lucide-react';

interface DashboardProps {
  onLogout: () => void;
  triggerToast: (msg: string, type: 'success' | 'warn' | 'error' | 'info') => void;
  onGoToPublic?: () => void;
}

type TabType = 'overview' | 'books' | 'categories' | 'authors' | 'members' | 'loans';

export const Dashboard: React.FC<DashboardProps> = ({ onLogout, triggerToast, onGoToPublic }) => {
  const [activeTab, setActiveTab] = useState<TabType>('overview');
  const [loading, setLoading] = useState(false);

  // Core Data Cache
  const [books, setBooks] = useState<Book[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [authors, setAuthors] = useState<Author[]>([]);
  const [members, setMembers] = useState<Member[]>([]);
  const [loans, setLoans] = useState<Loan[]>([]);

  // Statistics Dashboard
  const [stats, setStats] = useState({
    totalBooks: 0,
    totalMembers: 0,
    totalActiveLoans: 0,
    totalEarnings: 0,
    categoryDistribution: [] as { name: string; count: number }[]
  });

  // Search/Filter states
  const [searchTerm, setSearchTerm] = useState('');

  // Modals & Forms states
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalType, setModalType] = useState<'create' | 'edit'>('create');
  const [editingId, setEditingId] = useState<string | null>(null);

  // --- MODEL FORMS STATE ---
  // Books fields
  const [bookTitle, setBookTitle] = useState('');
  const [bookAuthorId, setBookAuthorId] = useState('');
  const [bookCategoryId, setBookCategoryId] = useState('');
  const [bookCoverUrl, setBookCoverUrl] = useState('');
  const [bookDescription, setBookDescription] = useState('');
  const [bookStock, setBookStock] = useState('5');
  const [bookRentalPrice, setBookRentalPrice] = useState('5000');
  const [bookRentalDuration, setBookRentalDuration] = useState('7');

  // Author fields
  const [authorName, setAuthorName] = useState('');
  const [authorBio, setAuthorBio] = useState('');

  // Category fields
  const [categoryName, setCategoryName] = useState('');

  // Member fields
  const [memberName, setMemberName] = useState('');
  const [memberEmail, setMemberEmail] = useState('');
  const [memberPhone, setMemberPhone] = useState('');
  const [memberType, setMemberType] = useState<'Regular' | 'Premium'>('Regular');

  // Loan fields
  const [loanMemberId, setLoanMemberId] = useState('');
  const [loanBookId, setLoanBookId] = useState('');


  // Fetch all database records
  const loadAllData = async () => {
    setLoading(true);
    try {
      const [b, c, a, m, l, s] = await Promise.all([
        api.books.list(),
        api.categories.list(),
        api.authors.list(),
        api.members.list(),
        api.loans.list(),
        api.dashboard.stats()
      ]);
      setBooks(b);
      setCategories(c);
      setAuthors(a);
      setMembers(m);
      setLoans(l);
      setStats(s);
    } catch (error: any) {
      triggerToast(error.message || "Gagal menghubungi REST API server.", "error");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadAllData();
  }, []);

  // Soft resetting Database to default seeds
  const handleResetDb = async () => {
    if (confirm("🚨 Apakah Anda yakin ingin MERESET Database? Semua data custom Anda akan dihapus, digantikan dengan seed default.")) {
      try {
        await api.dashboard.resetDb();
        triggerToast("Database berhasil di-reset ke data bawaan!", "success");
        await loadAllData();
      } catch (error: any) {
        triggerToast(error.message, "error");
      }
    }
  };

  // Open modals & initialize form states
  const openCreateModal = () => {
    setModalType('create');
    setEditingId(null);
    
    // Reset forms
    setBookTitle('');
    setBookAuthorId(authors[0]?.id || '');
    setBookCategoryId(categories[0]?.id || '');
    setBookCoverUrl('');
    setBookDescription('');
    setBookStock('5');
    setBookRentalPrice('5000');
    setBookRentalDuration('7');

    setAuthorName('');
    setAuthorBio('');

    setCategoryName('');

    setMemberName('');
    setMemberEmail('');
    setMemberPhone('');
    setMemberType('Regular');

    setLoanMemberId(members[0]?.id || '');
    setLoanBookId(books[0]?.id || '');

    setIsModalOpen(true);
  };

  const openEditModal = (item: any) => {
    setModalType('edit');
    setEditingId(item.id);

    if (activeTab === 'books') {
      setBookTitle(item.title);
      setBookAuthorId(item.authorId);
      setBookCategoryId(item.categoryId);
      setBookCoverUrl(item.coverUrl);
      setBookDescription(item.description);
      setBookStock(String(item.stock));
      setBookRentalPrice(String(item.rentalPrice));
      setBookRentalDuration(String(item.rentalDuration));
    } else if (activeTab === 'authors') {
      setAuthorName(item.name);
      setAuthorBio(item.bio);
    } else if (activeTab === 'categories') {
      setCategoryName(item.name);
    } else if (activeTab === 'members') {
      setMemberName(item.name);
      setMemberEmail(item.email);
      setMemberPhone(item.phone);
      setMemberType(item.membershipType);
    }

    setIsModalOpen(true);
  };

  // SUBMIT FORM ACTION (Creates or Edits depending on type)
  const handleSubmitForm = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (activeTab === 'books') {
        if (!bookTitle) throw new Error("Judul buku wajib diisi!");
        const payload = {
          title: bookTitle,
          authorId: bookAuthorId,
          categoryId: bookCategoryId,
          coverUrl: bookCoverUrl,
          description: bookDescription,
          stock: Number(bookStock),
          rentalPrice: Number(bookRentalPrice),
          rentalDuration: Number(bookRentalDuration),
        };

        if (modalType === 'create') {
          await api.books.create(payload);
          triggerToast("Buku baru berhasil ditambahkan ke katalog!", "success");
        } else {
          await api.books.update(editingId!, payload);
          triggerToast("Informasi buku berhasil diperbarui!", "success");
        }
      } 
      
      else if (activeTab === 'authors') {
        if (!authorName) throw new Error("Nama penulis wajib diisi!");
        const payload = { name: authorName, bio: authorBio };
        
        if (modalType === 'create') {
          await api.authors.create(payload);
          triggerToast("Profil Penulis berhasil ditambahkan!", "success");
        } else {
          await api.authors.update(editingId!, payload);
          triggerToast("Informasi Penulis berhasil diperbarui!", "success");
        }
      } 
      
      else if (activeTab === 'categories') {
        if (!categoryName) throw new Error("Nama kategori wajib diisi!");
        const payload = { name: categoryName };
        
        if (modalType === 'create') {
          await api.categories.create(payload);
          triggerToast("Kategori baru berhasil ditambahkan!", "success");
        } else {
          await api.categories.update(editingId!, payload);
          triggerToast("Nama kategori berhasil dirubah!", "success");
        }
      } 
      
      else if (activeTab === 'members') {
        if (!memberName || !memberEmail) throw new Error("Nama dan Email anggota wajib diisi!");
        const payload = { 
          name: memberName, 
          email: memberEmail, 
          phone: memberPhone, 
          membershipType: memberType 
        };
        
        if (modalType === 'create') {
          await api.members.create(payload);
          triggerToast("Anggota baru berhasil diregistrasi!", "success");
        } else {
          await api.members.update(editingId!, payload);
          triggerToast("Profil anggota berhasil diperbarui!", "success");
        }
      } 
      
      else if (activeTab === 'loans') {
        if (!loanMemberId || !loanBookId) throw new Error("Pilih Anggota dan Buku dengan benar!");
        await api.loans.create({ memberId: loanMemberId, bookId: loanBookId });
        triggerToast("Sirkulasi sewa baru berhasil dicatat!", "success");
      }

      setIsModalOpen(false);
      await loadAllData();
    } catch (err: any) {
      triggerToast(err.message, "error");
    }
  };

  // DELETE ACTION
  const handleDeleteItem = async (id: string, name: string) => {
    if (confirm(`🚨 Anda yakin ingin menghapus "${name}"? Tindakan ini tidak dapat dibatalkan.`)) {
      try {
        if (activeTab === 'books') {
          await api.books.delete(id);
        } else if (activeTab === 'authors') {
          await api.authors.delete(id);
        } else if (activeTab === 'categories') {
          await api.categories.delete(id);
        } else if (activeTab === 'members') {
          await api.members.delete(id);
        } else if (activeTab === 'loans') {
          await api.loans.delete(id);
        }
        triggerToast("Data berhasil dihapus dari RESTful API Server.", "info");
        await loadAllData();
      } catch (error: any) {
        triggerToast(error.message || "Gagal menghapus data.", "error");
      }
    }
  };

  // ACTION: RETURN BOOK LOGIC
  const handleReturnBook = async (id: string, bookTitle: string) => {
    try {
      await api.loans.return(id);
      triggerToast(`Buku "${bookTitle}" berhasil dikembalikan! Unit stok bertambah.`, "success");
      await loadAllData();
    } catch (error: any) {
      triggerToast(error.message, "error");
    }
  };

  // Searching filter on current active records
  const getFilteredItems = () => {
    const q = searchTerm.toLowerCase();
    switch (activeTab) {
      case 'overview':
        return [];
      case 'books':
        return books.filter(b => b.title.toLowerCase().includes(q) || (b as any).authorName?.toLowerCase().includes(q));
      case 'categories':
        return categories.filter(c => c.name.toLowerCase().includes(q) || c.slug.toLowerCase().includes(q));
      case 'authors':
        return authors.filter(a => a.name.toLowerCase().includes(q) || a.bio.toLowerCase().includes(q));
      case 'members':
        return members.filter(m => m.name.toLowerCase().includes(q) || m.email.toLowerCase().includes(q) || m.phone.includes(q));
      case 'loans':
        return loans.filter(l => (l as any).bookTitle.toLowerCase().includes(q) || (l as any).memberName.toLowerCase().includes(q));
    }
  };

  const filteredItems = getFilteredItems();

  return (
    <div className="w-full min-h-screen bg-[#F3F4F6] flex flex-col lg:flex-row overflow-hidden font-sans text-black">
      {/* Sidebar Navigation */}
      <aside className="w-full lg:w-64 bg-[#FFE500] border-b-4 lg:border-b-0 lg:border-r-4 border-black flex flex-col shrink-0 select-none">
        <div className="p-6 border-b-4 border-black flex items-center justify-between lg:block">
          <div>
            <h1 className="text-3xl font-black uppercase tracking-tighter leading-none text-black">
              BIBLIO<br className="hidden lg:block" />TECH
            </h1>
            <span className="text-xs font-bold bg-black text-white px-2 py-1 mt-2 inline-block uppercase rotate-[-1deg]">
              Admin v2.0
            </span>
          </div>
          <div className="lg:hidden">
            <button
              onClick={onLogout}
              className="px-3 py-1.5 bg-black text-white text-xs font-black uppercase tracking-tight hover:bg-zinc-800 transition-colors cursor-pointer"
            >
              LOGOUT →
            </button>
          </div>
        </div>
        
        {/* Sidebar Nav Buttons mapping perfectly to the 6 tabs with color icons */}
        <nav className="p-4 space-y-3 flex lg:flex-col overflow-x-auto lg:overflow-x-visible shrink-0 lg:flex-1 gap-2 lg:gap-0 select-none pb-4">
          {([
            { id: 'overview', label: 'Dashboard', hover: 'hover:bg-pink-400' },
            { id: 'books', label: 'Buku & Komik', hover: 'hover:bg-blue-400' },
            { id: 'categories', label: 'Kategori', hover: 'hover:bg-green-400' },
            { id: 'authors', label: 'Penulis', hover: 'hover:bg-amber-400' },
            { id: 'loans', label: 'Peminjaman', hover: 'hover:bg-purple-400' },
            { id: 'members', label: 'Anggota', hover: 'hover:bg-pink-400' }
          ] as const).map((tab) => {
            const isActive = activeTab === tab.id;
            return (
              <div
                key={tab.id}
                onClick={() => { setActiveTab(tab.id); setSearchTerm(''); }}
                className={`p-3 transition-all flex items-center gap-2.5 cursor-pointer whitespace-nowrap shrink-0 ${
                  isActive
                    ? 'bg-black text-white border-2 border-black shadow-[3px_3px_0px_0px_rgba(0,0,0,1)]'
                    : `bg-white text-black border-4 border-black ${tab.hover}`
                }`}
              >
                <div className={`w-4 h-4 border-2 border-black shrink-0 ${isActive ? 'bg-white' : 'bg-black/10'}`} />
                <span className={`text-xs md:text-sm uppercase font-black tracking-tight ${isActive ? 'text-white' : 'text-black'}`}>
                  {tab.label}
                </span>
              </div>
            );
          })}
        </nav>

        {/* Sidebar bottom footer area */}
        <div className="p-4 border-t-4 border-black bg-white hidden lg:block border-t">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-neo-teal border-2 border-black rounded-full flex items-center justify-center font-bold text-black font-display text-sm shadow-[2px_2px_0px_#000]">AD</div>
            <div>
              <p className="text-xs font-black uppercase text-black line-clamp-1">ADMIN UTAMA</p>
              <button onClick={onLogout} className="text-[10px] font-bold text-gray-600 hover:text-red-600 cursor-pointer block uppercase text-left">LOGOUT →</button>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-1.5 pt-3 mt-3 border-t-2 border-dashed border-black/20">
            <button 
              onClick={loadAllData} 
              className="text-[10px] font-bold uppercase py-1 px-1 bg-white hover:bg-zinc-100 text-black border-2 border-black shadow-[2px_2px_0px_#000] text-center active:translate-x-0.5 active:translate-y-0.5 transition-all cursor-pointer"
              title="Sinkronkan data live"
            >
              🔄 SYNC
            </button>
            <button 
              onClick={handleResetDb} 
              className="text-[10px] font-bold uppercase py-1 px-1 bg-neo-orange text-white border-2 border-black shadow-[2px_2px_0px_#000] text-center hover:bg-[#ff692a] active:translate-x-0.5 active:translate-y-0.5 transition-all cursor-pointer"
              title="Mereset database ke bawaan"
            >
              🚨 RESET
            </button>
          </div>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col bg-[#60A5FA] min-h-[calc(100vh-140px)] lg:h-screen lg:overflow-y-auto">
        {/* Top Header */}
        <header className="h-20 bg-white border-b-4 border-black flex items-center justify-between px-6 sm:px-8 shrink-0">
          <h2 className="text-lg sm:text-2xl font-black uppercase tracking-tight text-black flex items-center gap-2">
            🔐 {activeTab === 'overview' && 'SYSTEM OVERVIEW'}
            {activeTab === 'books' && 'KATALOG BUKU & KOMIK'}
            {activeTab === 'categories' && 'MANAJEMEN KATEGORI'}
            {activeTab === 'authors' && 'DAFTAR PENULIS & BIO'}
            {activeTab === 'loans' && 'ADMINISTRASI PEMINJAMAN'}
            {activeTab === 'members' && 'REGISTRASI ANGGOTA'}
          </h2>
          <div className="flex gap-2 sm:gap-4 shrink-0">
            {activeTab !== 'overview' && (
              <button 
                onClick={openCreateModal}
                className="px-4 py-2 bg-[#FF6AC1] border-4 border-black shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] font-black uppercase text-xs sm:text-sm hover:translate-x-[1.5px] hover:translate-y-[1.5px] hover:shadow-none transition-all cursor-pointer text-black animate-pulse"
              >
                + TAMBAH
              </button>
            )}
            <button 
              onClick={onGoToPublic}
              className="px-4 py-2 bg-white hover:bg-zinc-100 border-4 border-black shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] font-black uppercase text-xs sm:text-sm hover:translate-x-[1.5px] hover:translate-y-[1.5px] hover:shadow-none transition-all cursor-pointer text-black"
              title="Lihat Portal Publik"
            >
              📖 KATALOG
            </button>
          </div>
        </header>

        {/* Statistics Grid & Main Viewport */}
        <div className="p-4 sm:p-8 flex-1 space-y-6">
          {activeTab === 'overview' ? (
            /* Tab: OVERVIEW (STATISTICS & CHARTS & LATEST CHRONICLE) */
            <div className="space-y-6">
              {/* Statistics Grid */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-white border-4 border-black p-6 shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] text-black">
                  <p className="text-xs font-black uppercase mb-1 opacity-60 text-zinc-600 font-bold">Total Koleksi Buku</p>
                  <p className="text-5xl font-black">{stats.totalBooks}</p>
                  <p className="text-[10px] font-bold mt-2 text-green-600 uppercase font-mono">Status: SINKRON</p>
                </div>
                <div className="bg-[#FBBF24] border-4 border-black p-6 shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] text-black">
                  <p className="text-xs font-black uppercase mb-1 font-bold">Sedang Dipinjam</p>
                  <p className="text-5xl font-black">{stats.totalActiveLoans}</p>
                  <p className="text-[10px] font-bold mt-2 underline cursor-pointer hover:text-black/80 uppercase font-mono" onClick={() => setActiveTab('loans')}>LIHAT DETAIL SIRKULASI</p>
                </div>
                <div className="bg-[#4ADE80] border-4 border-black p-6 shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] text-black">
                  <p className="text-xs font-black uppercase mb-1 font-bold">Anggota Aktif</p>
                  <p className="text-5xl font-black">{stats.totalMembers}</p>
                  <p className="text-[10px] font-bold mt-2 uppercase font-mono">Status: AKTIF / STABIL</p>
                </div>
              </div>

              {/* Charts Grid */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2">
                  <NeoCard headerText="STATISTIK MASTER BUKU PER KATEGORI" headerAccent="bg-neo-yellow" shadow={true}>
                    <div className="h-64 mt-2">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={stats.categoryDistribution} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                          <CartesianGrid strokeDasharray="3 3" stroke="#000" vertical={false} />
                          <XAxis 
                            dataKey="name" 
                            tick={{ fill: '#000', fontSize: 10, fontWeight: 'bold' }} 
                            axisLine={{ stroke: '#000', strokeWidth: 2 }}
                            tickLine={{ stroke: '#000', strokeWidth: 2 }} 
                          />
                          <YAxis 
                            tick={{ fill: '#000', fontSize: 10, fontWeight: 'bold' }} 
                            axisLine={{ stroke: '#000', strokeWidth: 2 }}
                            tickLine={{ stroke: '#000', strokeWidth: 2 }} 
                          />
                          <Tooltip 
                            contentStyle={{ 
                              backgroundColor: '#faf8f5', 
                              borderRadius: '0px', 
                              border: '2px solid #000000', 
                              fontFamily: 'monospace',
                              fontWeight: 'bold'
                            }} 
                          />
                          <Bar dataKey="count" fill="#FF6AC1" stroke="#000000" strokeWidth={2} />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </NeoCard>
                </div>

                <div>
                  <NeoCard headerText="RIWAYAT SIRKULASI TERBARU" headerAccent="bg-neo-magenta text-white" shadow={true} className="h-full">
                    <div className="space-y-4 max-h-64 overflow-y-auto">
                      {loans.slice(-4).reverse().map((l: any) => (
                        <div key={l.id} className="border-2 border-black bg-[#ffffff] p-2.5 relative flex flex-col space-y-1 shadow-[2px_2px_0px_rgba(0,0,0,1)]">
                          <div className="flex justify-between items-start">
                            <span className="font-display font-black text-xs line-clamp-1 text-black">{l.bookTitle}</span>
                            <NeoBadge color={l.status === 'Active' ? 'teal' : 'yellow'}>
                              {l.status === 'Active' ? 'Aktif' : 'Kembali'}
                            </NeoBadge>
                          </div>
                          <div className="flex justify-between text-[11px] font-mono text-zinc-600">
                            <span>Penyewa: <b>{l.memberName}</b></span>
                            <span>Rp {l.totalFee.toLocaleString('id-ID')}</span>
                          </div>
                        </div>
                      ))}
                      {loans.length === 0 && (
                        <p className="font-mono text-xs text-zinc-500 text-center py-6">Belum ada catatan transaksi sewa.</p>
                      )}
                    </div>
                  </NeoCard>
                </div>
              </div>

              {/* Table Section: Koleksi Terbaru list */}
              <div className="bg-white border-4 border-black shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] flex flex-col">
                <div className="p-4 border-b-4 border-black bg-pink-200 flex justify-between items-center text-black">
                  <h3 className="font-black uppercase">Koleksi Terbaru</h3>
                  <div className="text-xs font-bold underline cursor-pointer" onClick={() => setActiveTab('books')}>LIHAT SEMUA BUKU & KOMIK</div>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-left font-mono text-xs md:text-sm text-black">
                    <thead className="bg-gray-100 border-b-2 border-black">
                      <tr>
                        <th className="p-4 text-xs font-black uppercase">ID Buku</th>
                        <th className="p-4 text-xs font-black uppercase">Judul</th>
                        <th className="p-4 text-xs font-black uppercase">Kategori</th>
                        <th className="p-4 text-xs font-black uppercase text-center">Stok</th>
                        <th className="p-4 text-xs font-black uppercase text-center">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y-2 divide-black">
                      {books.slice(-4).reverse().map((b) => (
                        <tr key={b.id} className="hover:bg-zinc-50 transition-colors">
                          <td className="p-4 font-mono text-xs font-bold text-zinc-500">#{b.id.substring(0, 8)}</td>
                          <td className="p-4 font-bold">{b.title}</td>
                          <td className="p-4">
                            <span className="bg-blue-200 border-2 border-black px-2 py-0.5 text-xs font-bold uppercase">
                              {b.categoryName || 'Manga / Novel'}
                            </span>
                          </td>
                          <td className="p-4 text-center font-bold">{b.stock} unit</td>
                          <td className="p-4">
                            <div className="flex items-center gap-2 justify-center">
                              <div className={`w-3 h-3 border border-black ${b.stock > 0 ? 'bg-green-500' : 'bg-red-500'}`} />
                              <span className="text-xs font-bold uppercase">{b.stock > 0 ? 'Tersedia' : 'Rented'}</span>
                            </div>
                          </td>
                        </tr>
                      ))}
                      {books.length === 0 && (
                        <tr>
                          <td colSpan={5} className="p-8 text-center text-zinc-500 font-mono text-xs">Belum ada buku di database.</td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          ) : (
            /* Tab: DETAILED DATABASE OPERATIONS (BOOKS, CATEGORIES, AUTHORS, MEMBERS, LOANS) */
            <div className="space-y-6">
              {/* Tab functional toolbar list */}
              <div className="flex flex-col md:flex-row items-center justify-between gap-4 bg-white p-4 border-4 border-black shadow-[4px_4px_0px_#000]">
                <div className="relative w-full md:max-w-md">
                  <NeoInput
                    placeholder={`Cari nama / detail pada data ${activeTab}...`}
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="mb-0"
                  />
                  <Search className="absolute right-3 top-[13.5px] w-4 h-4 text-zinc-500" />
                </div>

                <div className="font-mono text-xs font-bold shrink-0 bg-neo-yellow/30 px-3 py-1.5 border-2 border-black">
                  Total Ditemukan: {filteredItems.length} Data
                </div>
              </div>

              {/* TABLE AREA */}
              {loading ? (
                <div className="flex flex-col items-center justify-center p-16 bg-white border-4 border-black shadow-[4px_4px_0px_#000]">
                  <div className="animate-spin w-8 h-8 border-4 border-black border-t-neo-magenta mb-4"></div>
                  <p className="font-display font-medium text-sm text-black uppercase">MENYELARASKAN DATA DENGAN REST API...</p>
                </div>
              ) : filteredItems.length === 0 ? (
                <div className="p-12 text-center bg-white border-4 border-black shadow-[4px_4px_0px_#000] text-black">
                  <p className="font-mono text-xs text-zinc-500">Tidak ada data yang ditemukan. Tambahkan data baru dengan tombol di atas.</p>
                </div>
              ) : (
                <div className="overflow-x-auto bg-white border-4 border-black shadow-[8px_8px_0px_#000]">
                  <table className="w-full text-left font-mono text-xs md:text-sm text-black">
                    <thead className="bg-black text-white font-display uppercase font-black text-xs">
                      <tr>
                        <th className="p-3 border-r border-black border-b-2">ID</th>
                        {activeTab === 'books' && (
                          <>
                            <th className="p-3 border-r border-black border-b-2">Judul Buku</th>
                            <th className="p-3 border-r border-black border-b-2">Penulis</th>
                            <th className="p-3 border-r border-black border-b-2">Kategori</th>
                            <th className="p-3 border-r border-black border-b-2 text-right">Harga Sewa</th>
                            <th className="p-3 border-r border-black border-b-2 text-center">Stok</th>
                            <th className="p-3 border-r border-black border-b-2 text-center">Maks Hari</th>
                          </>
                        )}
                        {activeTab === 'categories' && (
                          <>
                            <th className="p-3 border-r border-black border-b-2">Nama Kategori</th>
                            <th className="p-3 border-r border-black border-b-2">Slug URL</th>
                          </>
                        )}
                        {activeTab === 'authors' && (
                          <>
                            <th className="p-3 border-r border-black border-b-2">Nama Penulis</th>
                            <th className="p-3 border-r border-black border-b-2">Profil Biografi</th>
                          </>
                        )}
                        {activeTab === 'members' && (
                          <>
                            <th className="p-3 border-r border-black border-b-2">Nama Lengkap</th>
                            <th className="p-3 border-r border-black border-b-2">Email</th>
                            <th className="p-3 border-r border-black border-b-2">No. HP</th>
                            <th className="p-3 border-r border-black border-b-2 text-center">Keanggotaan</th>
                          </>
                        )}
                        {activeTab === 'loans' && (
                          <>
                            <th className="p-3 border-r border-black border-b-2">Buku</th>
                            <th className="p-3 border-r border-black border-b-2">Anggota</th>
                            <th className="p-3 border-r border-black border-b-2">Tanggal Pinjam</th>
                            <th className="p-3 border-r border-black border-b-2">Tanggal Kembali</th>
                            <th className="p-3 border-r border-black border-b-2 text-center">Total Biaya</th>
                            <th className="p-3 border-r border-black border-b-2 text-center">Status</th>
                          </>
                        )}
                        <th className="p-3 border-b-2 text-center">Aksi</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y-2 divide-black">
                      {filteredItems.map((item: any) => (
                        <tr key={item.id} className="hover:bg-zinc-50 transition-colors">
                          <td className="p-3 font-bold border-r border-black bg-zinc-50 text-black">
                            {item.id.substring(0, 8)}...
                          </td>
                          
                          {/* Books cells */}
                          {activeTab === 'books' && (
                            <>
                              <td className="p-3 border-r border-black font-display font-medium text-black flex items-center gap-2">
                                <img 
                                  src={item.coverUrl} 
                                  alt="" 
                                  className="w-8 h-8 rounded-none object-cover border-2 border-black shrink-0" 
                                  referrerPolicy="no-referrer"
                                />
                                <span className="line-clamp-1">{item.title}</span>
                              </td>
                              <td className="p-3 border-r border-black text-black">{item.authorName}</td>
                              <td className="p-3 border-r border-black">
                                <NeoBadge color="magenta">{item.categoryName}</NeoBadge>
                              </td>
                              <td className="p-3 border-r border-black text-right font-bold text-black border-r">
                                Rp {item.rentalPrice.toLocaleString('id-ID')}
                              </td>
                              <td className="p-3 border-r border-black text-center font-bold text-black border-r">
                                <span className={item.stock > 0 ? 'text-green-700 font-extrabold' : 'text-red-600 font-extrabold'}>
                                  {item.stock}
                                </span>
                              </td>
                              <td className="p-3 border-r border-black text-center text-black">{item.rentalDuration} h</td>
                            </>
                          )}

                          {/* Categories cells */}
                          {activeTab === 'categories' && (
                            <>
                              <td className="p-3 border-r border-black text-black font-display font-medium">{item.name}</td>
                              <td className="p-3 border-r border-black text-zinc-500">{item.slug}</td>
                            </>
                          )}

                          {/* Authors cells */}
                          {activeTab === 'authors' && (
                            <>
                              <td className="p-3 border-r border-black text-black font-display font-medium whitespace-nowrap">{item.name}</td>
                              <td className="p-3 border-r border-black text-black max-w-xs truncate">{item.bio}</td>
                            </>
                          )}

                          {/* Members cells */}
                          {activeTab === 'members' && (
                            <>
                              <td className="p-3 border-r border-black text-black font-display font-medium">{item.name}</td>
                              <td className="p-3 border-r border-black text-black">{item.email}</td>
                              <td className="p-3 border-r border-black text-black">{item.phone}</td>
                              <td className="p-3 border-r border-black text-center">
                                <NeoBadge color={item.membershipType === 'Premium' ? 'magenta' : 'green'}>
                                  {item.membershipType}
                                </NeoBadge>
                              </td>
                            </>
                          )}

                          {/* Loans cells */}
                          {activeTab === 'loans' && (
                            <>
                              <td className="p-3 border-r border-black text-black font-display font-medium truncate max-w-44" title={item.bookTitle}>
                                {item.bookTitle}
                              </td>
                              <td className="p-3 border-r border-black text-black font-bold">{item.memberName}</td>
                              <td className="p-3 border-r border-black text-black whitespace-nowrap">
                                {new Date(item.loanDate).toLocaleDateString('id-ID', { hour: '2-digit', minute:'2-digit' })}
                              </td>
                              <td className="p-3 border-r border-black text-black whitespace-nowrap">
                                {item.returnDate 
                                  ? new Date(item.returnDate).toLocaleDateString('id-ID', { hour: '2-digit', minute:'2-digit' }) 
                                  : '-'
                                }
                              </td>
                              <td className="p-3 border-r border-black text-right font-bold text-black border-r">
                                Rp {item.totalFee.toLocaleString('id-ID')}
                              </td>
                              <td className="p-3 border-r border-black text-center">
                                <NeoBadge color={item.status === 'Active' ? 'teal' : 'yellow'}>
                                  {item.status === 'Active' ? 'Aktif' : 'Kembali'}
                                </NeoBadge>
                              </td>
                            </>
                          )}

                          {/* Action columns */}
                          <td className="p-2 gap-1.5 flex items-center justify-center">
                            {activeTab === 'loans' && item.status === 'Active' && (
                              <NeoButton 
                                variant="green" 
                                size="sm" 
                                shadow={false}
                                onClick={() => handleReturnBook(item.id, item.bookTitle)}
                                className="py-1 px-2.5 h-8 text-[11px] font-black"
                              >
                                <CheckCircle className="w-3.5 h-3.5 mr-1" /> Kembali
                              </NeoButton>
                            )}
                            
                            {activeTab !== 'loans' && (
                              <button
                                onClick={() => openEditModal(item)}
                                className="neo-border-thin bg-neo-yellow hover:bg-[#ffed4a] transition-all p-1.5 cursor-pointer shadow-[1px_1px_0px_#000]"
                                title="Edit Data"
                              >
                                <Edit className="w-3.5 h-3.5 text-black" />
                              </button>
                            )}

                            <button
                              onClick={() => handleDeleteItem(item.id, item.title || item.name || `Peminjaman ${item.bookTitle}`)}
                              className="neo-border-thin bg-neo-orange hover:bg-[#ff692a] text-white transition-all p-1.5 cursor-pointer shadow-[1px_1px_0px_#000]"
                              title="Hapus Data"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}
        </div>
      </main>

      {/* 5. MODALS VIEWPORT OVERLAYS */}
      <NeoModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={
          modalType === 'create' 
            ? `CATAT DATA ${activeTab.toUpperCase()}` 
            : `UBAH DATA ${activeTab.toUpperCase()}`
        }
        accentColor={activeTab === 'loans' ? 'magenta' : activeTab === 'books' ? 'yellow' : 'teal'}
      >
        <form onSubmit={handleSubmitForm} className="space-y-4">
          {/* Active Tab: BOOKS FORM */}
          {activeTab === 'books' && (
            <div className="space-y-3">
              <NeoInput
                label="Judul Buku / Komik"
                placeholder="cth: Akira Vol. 1"
                value={bookTitle}
                onChange={(e) => setBookTitle(e.target.value)}
                required
              />

              <div className="grid grid-cols-2 gap-3">
                <NeoSelect
                  label="Penulis"
                  value={bookAuthorId}
                  onChange={(e) => setBookAuthorId(e.target.value)}
                  options={authors.map(a => ({ value: a.id, label: a.name }))}
                />
                
                <NeoSelect
                  label="Kategori"
                  value={bookCategoryId}
                  onChange={(e) => setBookCategoryId(e.target.value)}
                  options={categories.map(c => ({ value: c.id, label: c.name }))}
                />
              </div>

              <NeoInput
                label="URL Sampul Gambar (Cover)"
                placeholder="Masukkan link gambar (https://...)"
                value={bookCoverUrl}
                onChange={(e) => setBookCoverUrl(e.target.value)}
              />

              <div className="flex flex-col w-full">
                <label className="font-display font-bold text-black text-sm mb-1.5">Sinopsis Singkat Buku</label>
                <textarea
                  className="w-full bg-white neo-border p-2 font-mono text-sm rounded-none outline-none focus:ring-2 focus:ring-black min-h-24 text-black"
                  placeholder="Ketik plot, ringkasan cerita atau detail di sini..."
                  value={bookDescription}
                  onChange={(e) => setBookDescription(e.target.value)}
                />
              </div>

              <div className="grid grid-cols-3 gap-3">
                <NeoInput
                  label="Stok Buku"
                  type="number"
                  min="0"
                  value={bookStock}
                  onChange={(e) => setBookStock(e.target.value)}
                />
                <NeoInput
                  label="Biaya Sewa (Rp)"
                  type="number"
                  min="500"
                  value={bookRentalPrice}
                  onChange={(e) => setBookRentalPrice(e.target.value)}
                />
                <NeoInput
                  label="Maksimal Hari"
                  type="number"
                  min="1"
                  value={bookRentalDuration}
                  onChange={(e) => setBookRentalDuration(e.target.value)}
                />
              </div>
            </div>
          )}

          {/* Active Tab: CATEGORIES FORM */}
          {activeTab === 'categories' && (
            <NeoInput
              label="Nama Kategori"
              placeholder="cth: Novel Sastra"
              value={categoryName}
              onChange={(e) => setCategoryName(e.target.value)}
              required
            />
          )}

          {/* Active Tab: AUTHORS ROUTE */}
          {activeTab === 'authors' && (
            <div className="space-y-4">
              <NeoInput
                label="Nama Penulis"
                placeholder="cth: Eiichiro Oda"
                value={authorName}
                onChange={(e) => setAuthorName(e.target.value)}
                required
              />
              <div className="flex flex-col w-full">
                <label className="font-display font-medium text-black text-sm mb-1.5">Biografi Penulis</label>
                <textarea
                  className="w-full bg-white neo-border p-2 font-mono text-sm rounded-none outline-none focus:ring-2 focus:ring-black min-h-24 text-black"
                  placeholder="Ketik riwayat hidup singkat di sini..."
                  value={authorBio}
                  onChange={(e) => setAuthorBio(e.target.value)}
                />
              </div>
            </div>
          )}

          {/* Active Tab: MEMBERS FORM */}
          {activeTab === 'members' && (
            <div className="space-y-3">
              <NeoInput
                label="Nama Lengkap Anggota"
                placeholder="cth: John Doe"
                value={memberName}
                onChange={(e) => setMemberName(e.target.value)}
                required
              />
              <NeoInput
                label="Alamat Email"
                type="email"
                placeholder="cth: johndoe@gmail.com"
                value={memberEmail}
                onChange={(e) => setMemberEmail(e.target.value)}
                required
              />
              <NeoInput
                label="Nomor Handphone"
                placeholder="cth: 0812XXXXXXXX"
                value={memberPhone}
                onChange={(e) => setMemberPhone(e.target.value)}
              />
              <NeoSelect
                label="Tipe Keanggotaan"
                value={memberType}
                onChange={(e) => setMemberType(e.target.value as any)}
                options={[
                  { value: 'Regular', label: '🟢 Regular (Biaya standar)' },
                  { value: 'Premium', label: '👑 Premium (Rent durasi ganda)' }
                ]}
              />
            </div>
          )}

          {/* Active Tab: LOANS FORM */}
          {activeTab === 'loans' && (
            <div className="space-y-4">
              {books.filter(b => b.stock > 0).length === 0 ? (
                <div className="bg-neo-orange/10 p-4 neo-border text-red-600 text-xs font-bold font-mono">
                  🚨 Tidak ada buku yang memiliki stok saat ini! Harap tambahkan stok buku di tab "Buku & Komik".
                </div>
              ) : members.length === 0 ? (
                <div className="bg-neo-orange/10 p-4 neo-border text-red-600 text-xs font-bold font-mono">
                  🚨 Tidak ada anggota terdaftar untuk meminjam buku! Hubungi tab "Anggota" terlebih dahulu.
                </div>
              ) : (
                <>
                  <NeoSelect
                    label="Pilih Anggota Penyewa"
                    value={loanMemberId}
                    onChange={(e) => setLoanMemberId(e.target.value)}
                    options={members.map(m => ({ value: m.id, label: `${m.name} (${m.membershipType})` }))}
                  />

                  <NeoSelect
                    label="Pilih Buku / Komik Digital (Hanya dengan Stok)"
                    value={loanBookId}
                    onChange={(e) => setLoanBookId(e.target.value)}
                    options={books.filter(b => b.stock > 0).map(b => ({ value: b.id, label: `${b.title} - Sisa Stok: ${b.stock}` }))}
                  />

                  {/* Informational price recap box */}
                  {(() => {
                    const selB = books.find(b => b.id === loanBookId);
                    if (!selB) return null;
                    return (
                      <div className="bg-neo-beige p-3 neo-border font-mono text-xs text-black">
                        <p className="font-extrabold uppercase mb-1">Rincian Sewa Otomatis:</p>
                        <p>💸 Biaya Sewa: <b>Rp {selB.rentalPrice.toLocaleString('id-ID')}</b></p>
                        <p>⏱️ Batasan Waktu: <b>{selB.rentalDuration} Hari</b></p>
                      </div>
                    );
                  })()}
                </>
              )}
            </div>
          )}

          <div className="pt-4 border-t-2 border-black flex justify-end gap-3">
            <NeoButton 
              type="button" 
              variant="white" 
              onClick={() => setIsModalOpen(false)}
            >
              Batalkan
            </NeoButton>
            
            {/* Conditional disables */}
            {activeTab === 'loans' && (books.filter(b => b.stock > 0).length === 0 || members.length === 0) ? (
              <NeoButton 
                type="submit" 
                variant="green"
                disabled
                className="opacity-50 cursor-not-allowed"
              >
                Catat Transaksi
              </NeoButton>
            ) : (
              <NeoButton 
                type="submit" 
                variant="green"
              >
                {modalType === 'create' ? 'Konfirmasi Simpan' : 'Update Perubahan'}
              </NeoButton>
            )}
          </div>
        </form>
      </NeoModal>
    </div>
  );
};
