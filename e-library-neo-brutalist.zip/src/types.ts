export interface Category {
  id: string;
  name: string;
  slug: string;
}

export interface Author {
  id: string;
  name: string;
  bio: string;
}

export interface Book {
  id: string;
  title: string;
  authorId: string;
  categoryId: string;
  coverUrl: string;
  description: string;
  stock: number;
  rentalPrice: number;
  rentalDuration: number; // in days
}

export interface Member {
  id: string;
  name: string;
  email: string;
  phone: string;
  membershipType: 'Regular' | 'Premium';
}

export interface Loan {
  id: string;
  memberId: string;
  bookId: string;
  loanDate: string; // ISO date string
  returnDate: string | null; // ISO date string or null if not returned yet
  status: 'Active' | 'Returned';
  totalFee: number;
}

export interface DashboardStats {
  totalBooks: number;
  totalMembers: number;
  totalActiveLoans: number;
  totalEarnings: number;
  categoryDistribution: { name: string; count: number }[];
  recentLoans: (Loan & { bookTitle: string; memberName: string })[];
}

export interface UserSession {
  token: string | null;
  username: string | null;
  role: 'admin' | 'public';
}
