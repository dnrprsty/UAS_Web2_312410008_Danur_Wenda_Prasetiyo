const BASE_URL = "";

// Global callback to trigger on Auth error (e.g., token expired or revoked)
let unauthorizedCallback: (() => void) | null = null;

export function registerUnauthorizedCallback(cb: () => void) {
  unauthorizedCallback = cb;
}

async function request(url: string, options: RequestInit = {}) {
  const token = localStorage.getItem("admin_token");
  const headers = {
    ...options.headers,
    "Content-Type": "application/json",
  } as Record<string, string>;

  if (token) {
    headers["Authorization"] = `Bearer ${token}`;
  }

  const response = await fetch(url, { ...options, headers });

  if (response.status === 401) {
    // Intercept 401 Unauthorized and execute callback
    if (unauthorizedCallback) {
      unauthorizedCallback();
    }
    const errData = await response.json().catch(() => ({}));
    throw new Error(errData.error || "Akses Tidak Diizinkan: Sesi admin Anda telah berakhir.");
  }

  if (!response.ok) {
    const errData = await response.json().catch(() => ({}));
    throw new Error(errData.error || `HTTP error! Status: ${response.status}`);
  }

  return response.json();
}

export const api = {
  auth: {
    login: async (body: any) => {
      const data = await request(`${BASE_URL}/api/auth/login`, {
        method: "POST",
        body: JSON.stringify(body)
      });
      if (data.token) {
        localStorage.setItem("admin_token", data.token);
        localStorage.setItem("admin_user", data.user.username);
      }
      return data;
    },
    logout: () => {
      localStorage.removeItem("admin_token");
      localStorage.removeItem("admin_user");
    }
  },
  
  books: {
    list: () => request(`${BASE_URL}/api/books`),
    create: (body: any) => request(`${BASE_URL}/api/books`, {
      method: "POST",
      body: JSON.stringify(body)
    }),
    update: (id: string, body: any) => request(`${BASE_URL}/api/books/${id}`, {
      method: "PUT",
      body: JSON.stringify(body)
    }),
    delete: (id: string) => request(`${BASE_URL}/api/books/${id}`, {
      method: "DELETE"
    })
  },

  categories: {
    list: () => request(`${BASE_URL}/api/categories`),
    create: (body: any) => request(`${BASE_URL}/api/categories`, {
      method: "POST",
      body: JSON.stringify(body)
    }),
    update: (id: string, body: any) => request(`${BASE_URL}/api/categories/${id}`, {
      method: "PUT",
      body: JSON.stringify(body)
    }),
    delete: (id: string) => request(`${BASE_URL}/api/categories/${id}`, {
      method: "DELETE"
    })
  },

  authors: {
    list: () => request(`${BASE_URL}/api/authors`),
    create: (body: any) => request(`${BASE_URL}/api/authors`, {
      method: "POST",
      body: JSON.stringify(body)
    }),
    update: (id: string, body: any) => request(`${BASE_URL}/api/authors/${id}`, {
      method: "PUT",
      body: JSON.stringify(body)
    }),
    delete: (id: string) => request(`${BASE_URL}/api/authors/${id}`, {
      method: "DELETE"
    })
  },

  members: {
    list: () => request(`${BASE_URL}/api/members`),
    create: (body: any) => request(`${BASE_URL}/api/members`, {
      method: "POST",
      body: JSON.stringify(body)
    }),
    update: (id: string, body: any) => request(`${BASE_URL}/api/members/${id}`, {
      method: "PUT",
      body: JSON.stringify(body)
    }),
    delete: (id: string) => request(`${BASE_URL}/api/members/${id}`, {
      method: "DELETE"
    })
  },

  loans: {
    list: () => request(`${BASE_URL}/api/loans`),
    create: (body: any) => request(`${BASE_URL}/api/loans`, {
      method: "POST",
      body: JSON.stringify(body)
    }),
    return: (id: string) => request(`${BASE_URL}/api/loans/${id}/return`, {
      method: "POST"
    }),
    delete: (id: string) => request(`${BASE_URL}/api/loans/${id}`, {
      method: "DELETE"
    })
  },

  dashboard: {
    stats: () => request(`${BASE_URL}/api/dashboard/stats`),
    resetDb: () => request(`${BASE_URL}/api/admin/reset-db`, {
      method: "POST"
    })
  }
};
