import React, { useState, useEffect } from 'react';
import { LandingPage } from './components/LandingPage';
import { Dashboard } from './components/Dashboard';
import { 
  NeoButton, NeoCard, NeoInput, NeoBadge, 
  NeoToastStack, ToastItem, ToastType 
} from './components/NeoBrutalist';
import { api, registerUnauthorizedCallback } from './api';
import { BookOpen, User, ShieldCheck, HelpCircle, Lock, LayoutGrid } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

type Route = 'landing' | 'admin';

export default function App() {
  const [currentRoute, setCurrentRoute] = useState<Route>('landing');
  const [isAdmin, setIsAdmin] = useState(false);
  const [adminUsername, setAdminUsername] = useState<string | null>(null);
  
  // Login Modal form states
  const [isLoginOpen, setIsLoginOpen] = useState(false);
  const [loginUser, setLoginUser] = useState('');
  const [loginPass, setLoginPass] = useState('');
  const [loginError, setLoginError] = useState('');
  const [loginLoading, setLoginLoading] = useState(false);

  // Global Toasts Queue list
  const [toasts, setToasts] = useState<ToastItem[]>([]);

  const addToast = (message: string, type: ToastType = 'success') => {
    const id = Date.now().toString();
    setToasts((prev) => [...prev, { id, message, type }]);
    setTimeout(() => removeToast(id), 4000);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // Sync token presence state
  const syncSessionState = () => {
    const token = localStorage.getItem("admin_token");
    const user = localStorage.getItem("admin_user");
    if (token) {
      setIsAdmin(true);
      setAdminUsername(user || "admin");
    } else {
      setIsAdmin(false);
      setAdminUsername(null);
    }
  };

  useEffect(() => {
    // Perform initial session check
    syncSessionState();

    // Register active 401 Interceptor hook
    registerUnauthorizedCallback(() => {
      api.auth.logout();
      syncSessionState();
      setCurrentRoute('landing');
      addToast("Sesi kedaluwarsa atau dilarang! Hak administrator dicabut.", "error");
    });
  }, []);

  // Admin login procedure
  const handleAdminLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError('');
    setLoginLoading(true);

    try {
      await api.auth.login({ username: loginUser, password: loginPass });
      syncSessionState();
      setIsLoginOpen(false);
      setLoginUser('');
      setLoginPass('');
      addToast("Selamat Datang, Anda masuk sebagai Administrator!", "success");
      setCurrentRoute('admin');
    } catch (error: any) {
      setLoginError(error.message || "Nama pengguna atau sandi keliru!");
      addToast("Autentikasi gagal. Silahkan cek kredensial.", "error");
    } finally {
      setLoginLoading(false);
    }
  };

  // Admin logout procedure
  const handleAdminLogout = () => {
    api.auth.logout();
    syncSessionState();
    setCurrentRoute('landing');
    addToast("Anda telah keluar dari akses administrator.", "info");
  };

  // Router guard for secure navigation
  const navigateTo = (route: Route) => {
    if (route === 'admin' && !isAdmin) {
      setLoginError('');
      setIsLoginOpen(true); // Intercept and prompt login modal
      addToast("Harap login terlebih dahulu untuk mengakses dashboard admin.", "warn");
    } else {
      setCurrentRoute(route);
    }
  };

  return (
    <div className="min-h-screen bg-neo-paper select-text">
      {currentRoute === 'landing' ? (
        <div className="pb-16">
          {/* 1. STARK NAVIGATION FRAME */}
          <nav className="border-b-4 border-black bg-white sticky top-0 z-40">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5 flex items-center justify-between">
              <div 
                className="flex items-center gap-2.5 cursor-pointer select-none group"
                onClick={() => setCurrentRoute('landing')}
              >
                <div className="bg-neo-magenta p-2 neo-border-thin shadow-[2px_2px_0px_#000] group-hover:-translate-y-0.5 group-hover:bg-neo-yellow transition-all">
                  <BookOpen className="w-5 h-5 text-white stroke-[2.5]" />
                </div>
                <div>
                  <span className="font-display font-black text-lg md:text-xl tracking-tighter text-black uppercase block leading-none">
                    E-LIBRARY
                  </span>
                  <span className="font-mono text-[9px] uppercase font-bold text-zinc-500 tracking-wider">
                    Digital Book Circulations
                  </span>
                </div>
              </div>

              {/* Navigation Items */}
              <div className="flex items-center gap-3">
                <button
                  onClick={() => setCurrentRoute('landing')}
                  className={`font-display font-bold text-xs md:text-sm px-4 py-2 transition-all cursor-pointer rounded-none text-black ${
                    currentRoute === 'landing' 
                      ? 'bg-neo-yellow neo-border shadow-[2px_2px_0px_#000]' 
                      : 'hover:bg-neo-beige border border-transparent'
                  }`}
                >
                  📖 Katalog Publik
                </button>

                <button
                  onClick={() => navigateTo('admin')}
                  className={`font-display font-bold text-xs md:text-sm px-4 py-2 transition-all cursor-pointer rounded-none text-black ${
                    currentRoute === 'admin' 
                      ? 'bg-neo-teal neo-border shadow-[2px_2px_0px_#000]' 
                      : 'hover:bg-neo-beige border border-transparent'
                  }`}
                >
                  🛠️ Dashboard Admin
                </button>

                {isAdmin ? (
                  <div className="hidden sm:flex items-center gap-2 bg-black text-white py-1 pl-2.5 pr-1.5 neo-border border-white shadow-[2px_2px_0px_#000] rotate-[1deg]">
                    <User className="w-3.5 h-3.5 text-neo-teal" />
                    <span className="font-mono text-[10px] font-black uppercase text-white tracking-widest">{adminUsername}</span>
                    <button
                      onClick={handleAdminLogout}
                      className="bg-neo-orange border border-black hover:bg-[#ff692a] text-white py-0.5 px-2 font-display text-[9px] font-bold tracking-tight uppercase cursor-pointer"
                    >
                      Logout
                    </button>
                  </div>
                ) : (
                  <NeoButton 
                    variant="magenta" 
                    size="sm" 
                    onClick={() => setIsLoginOpen(true)}
                    className="hidden sm:inline-flex"
                  >
                    Admin Login
                  </NeoButton>
                )}
              </div>
            </div>
          </nav>

          {/* 2. CORE CONTENT RENDER WITH MICRO-ANIMATIONS */}
          <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8">
            <AnimatePresence mode="wait">
              <motion.div
                key={currentRoute}
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -15 }}
                transition={{ duration: 0.18 }}
              >
                <LandingPage 
                  onOpenLogin={() => setIsLoginOpen(true)}
                  isAdmin={isAdmin}
                  onGoToAdmin={() => setCurrentRoute('admin')}
                  triggerToast={addToast}
                />
              </motion.div>
            </AnimatePresence>
          </main>
        </div>
      ) : (
        <Dashboard 
          onLogout={handleAdminLogout}
          triggerToast={addToast}
          onGoToPublic={() => setCurrentRoute('landing')}
        />
      )}

      {/* 3. PINTU MASUK ADMIN (LOGIN MODAL OVERLAY) */}
      <AnimatePresence>
        {isLoginOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <div className="fixed inset-0 bg-black/60 backdrop-blur-xs" onClick={() => setIsLoginOpen(false)} />
            <motion.div
              initial={{ scale: 0.9, y: 30, opacity: 0 }}
              animate={{ scale: 1, y: 0, opacity: 1 }}
              exit={{ scale: 0.9, y: 30, opacity: 0 }}
              className="z-10 w-full max-w-sm"
            >
              <NeoCard
                accentColor="magenta"
                headerText="PINTU MASUK PETUGAS ADMIN"
                headerAccent="bg-neo-magenta text-white"
                className="neo-shadow-lg"
              >
                <div className="bg-neo-yellow/10 border-2 border-neo-yellow p-3 mb-4 rounded-none flex items-start gap-2 text-black">
                  <Lock className="w-5 h-5 shrink-0 text-black border neo-border-thin bg-neo-yellow p-0.5 mt-0.5" />
                  <div className="font-mono text-[10px] leading-relaxed">
                    <span className="font-extrabold uppercase text-black block mb-0.5">Akses Terkunci!</span>
                    Gunakan kredensial default untuk verifikasi akses: <br />
                    Username: <b className="bg-white px-1 select-all">admin</b> <br />
                    Password: <b className="bg-white px-1 select-all">admin123</b>
                  </div>
                </div>

                <form onSubmit={handleAdminLogin} className="space-y-4">
                  <NeoInput
                    label="Nama Pengguna (Username)"
                    placeholder="Masukkan username admin"
                    value={loginUser}
                    onChange={(e) => setLoginUser(e.target.value)}
                    required
                  />

                  <NeoInput
                    label="Kata Sandi (Password)"
                    type="password"
                    placeholder="Masukkan sandi petugas"
                    value={loginPass}
                    onChange={(e) => setLoginPass(e.target.value)}
                    required
                  />

                  {loginError && (
                    <div className="neo-border bg-neo-orange/15 p-2 font-mono text-[10px] font-bold text-red-600">
                      ⚠️ {loginError}
                    </div>
                  )}

                  <div className="pt-2 flex justify-between gap-3">
                    <NeoButton 
                      type="button" 
                      variant="white" 
                      onClick={() => setIsLoginOpen(false)}
                      className="w-1/2"
                    >
                      Kembali
                    </NeoButton>
                    <NeoButton 
                      type="submit" 
                      variant="yellow"
                      className="w-1/2"
                      disabled={loginLoading}
                    >
                      {loginLoading ? 'Loading...' : 'Verifikasi'}
                    </NeoButton>
                  </div>
                </form>
              </NeoCard>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* 4. SYSTEM-WIDE PERSISTENT TOAST BLOCK */}
      <NeoToastStack toasts={toasts} removeToast={removeToast} />
    </div>
  );
}
